package com.tvg.server.response;

import org.json.JSONObject;

import com.tvg.server.exception.TVGException;
import com.tvg.server.util.bean.ResponseStatusBean;

public class RegistrationResponse {

	public static JSONObject generateRegistrationResp(ResponseStatusBean responseStatus){
		JSONObject parentObject = new JSONObject();
		try{
			parentObject.put("return_code", ""+responseStatus.getReturnCode());
			if(responseStatus.getReturnCode() == 0){
				parentObject.put("response", "You have been registered successfully.");
			}else{
				parentObject.put("error_text", responseStatus.getErrorText());
			}
		}catch(Exception ex){
			new TVGException("Error in generating response for user registration : "+ex);
		}
		return parentObject;
	}
	
	public static JSONObject generateCheckUserResp(ResponseStatusBean responseStatus){
		JSONObject parentObject = new JSONObject();
		try{
			parentObject.put("return_code", ""+responseStatus.getReturnCode());
			if(responseStatus.getReturnCode() == 0){
				parentObject.put("response", "Username is available.");
			}else{
				parentObject.put("error_text", responseStatus.getErrorText());
			}
		}catch(Exception ex){
			new TVGException("Error in generating response for user validation : "+ex);
		}
		return parentObject;
	}
	
}
