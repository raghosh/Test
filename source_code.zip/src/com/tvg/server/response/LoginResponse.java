package com.tvg.server.response;

import java.util.Iterator;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;


import com.tvg.server.constant.Constants;
import com.tvg.server.exception.TVGException;
import com.tvg.server.util.bean.CategoryBean;
import com.tvg.server.util.bean.LoginResponseBean;
import com.tvg.server.util.bean.MilestoneBean;

public class LoginResponse {

	public static JSONObject generateLoginResponse(LoginResponseBean response){
		JSONObject parentObject = new JSONObject();
		JSONArray categoryArr = new JSONArray();
		JSONArray milestoneArr;
		Iterator<CategoryBean> categoryIt;
		Iterator<MilestoneBean> milestoneIt;
		CategoryBean categoryBean;
		MilestoneBean milestoneBean;
		try{
			parentObject.put("return_code", ""+response.getReturn_code());
			if(response.getReturn_code() == 0){
				// General Info
				parentObject.put("firstName", response.getFirstName());
				parentObject.put("midName", response.getMidName());
				parentObject.put("lastName", response.getLastName());
				parentObject.put("sex", response.getSex());
				parentObject.put("profile_picture", Constants.BASE_URL+Constants.PROFILE_PICTURE_URI+response.getUserName());
				// Category Info
				categoryIt = response.getCategories().iterator();
				while(categoryIt.hasNext()){
					categoryBean = categoryIt.next();
					JSONObject categoryJSON = new JSONObject();
					categoryJSON.put("id", categoryBean.getId());
					categoryJSON.put("name", categoryBean.getCategory_name());
					// Milestone Info
					milestoneIt = categoryBean.getMilestones().iterator();
					milestoneArr = new JSONArray();
					while(milestoneIt.hasNext()){
						JSONObject milestoneJSON = new JSONObject();
						milestoneBean = milestoneIt.next();
						milestoneJSON.put("id", milestoneBean.getMilestoneId());
						milestoneJSON.put("name", milestoneBean.getMilestone_name());
						milestoneJSON.put("description", milestoneBean.getDescription());
						
						if(milestoneBean.getCover_image() != null){
							if(milestoneBean.getCover_image().contains("http"))
								milestoneJSON.put("cover_image", milestoneBean.getCover_image());
							else
								milestoneJSON.put("cover_image", Constants.BASE_URL+milestoneBean.getCover_image());
						}else{
							milestoneJSON.put("cover_image", Constants.BASE_URL+Constants.SHARE_IMAGE_URI+Constants.UID+Constants.NO_IMAGE);
						}
						milestoneArr.add(milestoneJSON);
					}
					// Setting milestone info into category info
					categoryJSON.put("milestones", milestoneArr);
					categoryArr.add(categoryJSON);
				}
				// Setting category info into general info
				parentObject.put("categories", categoryArr);
				
			}else{
				parentObject.put("error_text", ""+response.getError_text());
			}
		}catch(Exception ex){
			new TVGException("Error in generating response for user login : "+ex);
		}
		return parentObject;
	}
	
}
