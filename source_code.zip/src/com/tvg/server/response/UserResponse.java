package com.tvg.server.response;

import java.util.Iterator;
import java.util.List;

import com.tvg.server.constant.Constants;
import com.tvg.server.exception.TVGException;
import com.tvg.server.util.bean.CategoryBean;
import com.tvg.server.util.bean.MilestoneBean;
import com.tvg.server.util.bean.ResponseStatusBean;
import com.tvg.server.util.bean.UserInfoBean;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class UserResponse {

	public static JSONObject viewProfileResponse(UserInfoBean response){
		JSONObject parentObject = new JSONObject();
		JSONArray categoryArr = new JSONArray();
		JSONObject categoryJSON;
		JSONArray userArr = new JSONArray();
		JSONObject userJSON;
		Iterator<Integer> followedCategoryIt;
		Iterator<CategoryBean> categoryIt;
		CategoryBean categoryBean;
		Iterator<UserInfoBean> userIt;
		UserInfoBean userBean;
		try{
			if(response.getUserName() != null){
				parentObject.put("return_code", 0);
				parentObject.put("firstName", response.getFirstName());
				parentObject.put("midName", response.getMidName());
				parentObject.put("lastName", response.getLastName());
				parentObject.put("sex", response.getSex());
				parentObject.put("profile_picture", Constants.BASE_URL+Constants.PROFILE_PICTURE_URI+response.getUserName());
				categoryIt = response.getCategoryList().iterator();
				followedCategoryIt = response.getFollowedCategoryList().iterator();
				while(categoryIt.hasNext()){
					categoryBean = categoryIt.next();
					categoryJSON = new JSONObject();
					categoryJSON.put("id", categoryBean.getId());
					categoryJSON.put("name", categoryBean.getCategory_name());
					categoryJSON.put("following", filterCategory(followedCategoryIt, categoryBean.getId()));
					
					categoryArr.add(categoryJSON);
				}
				parentObject.put("categories", categoryArr);
				
				userIt = response.getFollwedUserList().iterator();
				while(userIt.hasNext()){
					userBean = userIt.next();
					userJSON = new JSONObject();
					userJSON.put("userName", userBean.getUserName());
					userJSON.put("firstName", userBean.getFirstName());
					userJSON.put("lastName", userBean.getLastName());
					userJSON.put("profile_picture", Constants.BASE_URL+Constants.PROFILE_PICTURE_URI+userBean.getUserName());
					
					userArr.add(userJSON);
				}
				parentObject.put("followers", userArr);
			}else{
				parentObject.put("return_code", 1);
			}
		}catch(Exception ex){
			new TVGException("Exception in view profile response : "+ex);
		}
		return parentObject;
	}
	
	public static JSONObject userMilestoneResponse(List<MilestoneBean> response){
		JSONObject parentObject = new JSONObject();
		Iterator<MilestoneBean> milestoneIt;
		MilestoneBean milestoneBean;
		JSONArray milestoneArr = new JSONArray();
		JSONObject milestoneJSON;
		try{
			milestoneIt = response.iterator();
			while(milestoneIt.hasNext()){
				milestoneBean = milestoneIt.next();
				milestoneJSON = new JSONObject();
				milestoneJSON.put("milestone_id", milestoneBean.getMilestoneId());
				milestoneJSON.put("name", milestoneBean.getMilestone_name());
				milestoneJSON.put("description", milestoneBean.getDescription());
				milestoneJSON.put("category", milestoneBean.getCategory());
				milestoneJSON.put("created_by", milestoneBean.getCreated_by());
				
				if(milestoneBean.getCover_image() != null){
					if(milestoneBean.getCover_image().contains("http"))
						milestoneJSON.put("cover_image", milestoneBean.getCover_image());
					else
						milestoneJSON.put("cover_image", Constants.BASE_URL+milestoneBean.getCover_image());
				}else{
					milestoneJSON.put("cover_image", Constants.BASE_URL+Constants.SHARE_IMAGE_URI+Constants.UID+Constants.NO_IMAGE);
				}
				milestoneArr.add(milestoneJSON);
			}
			parentObject.put("milestones", milestoneArr);
		}catch(Exception ex){
			new TVGException("Exception in user milestone response : "+ex);
		}
		return parentObject;
	}
	
	public static JSONObject generateCheckEmailResp(ResponseStatusBean responseStatus){
		JSONObject parentObject = new JSONObject();
		try{
			parentObject.put("return_code", ""+responseStatus.getReturnCode());
			if(responseStatus.getReturnCode() == 0){
				parentObject.put("response", "Email Id is available.");
			}else{
				parentObject.put("error_text", responseStatus.getErrorText());
			}
		}catch(Exception ex){
			new TVGException("Error in generating response for email validation : "+ex);
		}
		return parentObject;
	}
	
	private static boolean filterCategory(Iterator<Integer> followedCategoryIt, int categoryId){
		try{
			while(followedCategoryIt.hasNext()){
				if(followedCategoryIt.next() == categoryId){
					return true;
				}
			}
		}catch(Exception ex){
			new TVGException("Exception in filterCategory : "+ex);
		}
		return false;
	}
	
}
