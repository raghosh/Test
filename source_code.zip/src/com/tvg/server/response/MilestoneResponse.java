package com.tvg.server.response;

import java.util.Iterator;
import java.util.List;

import com.tvg.server.constant.Constants;
import com.tvg.server.exception.TVGException;
import com.tvg.server.util.bean.CommentBean;
import com.tvg.server.util.bean.ItemDetailsBean;
import com.tvg.server.util.bean.MilestoneDetailsBean;
import com.tvg.server.util.bean.ResponseStatusBean;
import com.tvg.server.util.bean.UserInfoBean;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class MilestoneResponse {

	public static JSONObject createMilestoneResponse(ResponseStatusBean responseStatus){
		JSONObject parentObject = new JSONObject();
		try{
			parentObject.put("return_code", ""+responseStatus.getReturnCode());
			if(responseStatus.getReturnCode() == 0){
				parentObject.put("response", "Milestone has been created sucessfully.");
			}else{
				parentObject.put("error_text", responseStatus.getErrorText());
			}
		}catch(Exception ex){
			new TVGException("Error in generating response for milestone creation : "+ex);
		}
		return parentObject;
	}
	
	public static JSONObject viewMilestoneResponse(MilestoneDetailsBean response){
		JSONObject parentObject = new JSONObject();
//		JSONArray itemArr = new JSONArray();
		JSONArray commentArr = new JSONArray();
		JSONArray memberArr;
		JSONObject userJSON;
//		JSONObject itemJSON;
		JSONObject commentJSON;
		Iterator<UserInfoBean> memberIt;
		UserInfoBean userBean;
//		Iterator<ItemDetailsBean> sharedItemsIt;
//		ItemDetailsBean sharedItemBean;
		Iterator<CommentBean> commentIt;
		CommentBean commentBean;
		try{
			parentObject.put("return_code", ""+response.getReturn_code());
			if(response.getReturn_code() == 0){
				parentObject.put("milestone_id", response.getMilestone_id());
				parentObject.put("milestone_name", response.getDisplay_name());
				parentObject.put("description", response.getDescription());
				parentObject.put("category_name", response.getCategory_name());
				parentObject.put("created_by", response.getCreated_by());
				parentObject.put("vote", response.getVote());
				parentObject.put("isMember", response.isMember());
				parentObject.put("isFollowing", response.isFollowing());
				
				if(response.getMilestoneMembers() != null){
					memberArr = new JSONArray();
					memberIt = response.getMilestoneMembers().iterator();
					while(memberIt.hasNext()){
						userJSON = new JSONObject();
						userBean = memberIt.next();
						userJSON.put("userName", userBean.getUserName());
						userJSON.put("firstName", userBean.getFirstName());
						userJSON.put("lastName", userBean.getLastName());
						userJSON.put("profile_picture", Constants.BASE_URL+Constants.PROFILE_PICTURE_URI+userBean.getUserName());
						
						memberArr.add(userJSON);
					}
				}else{
					memberArr = new JSONArray();
				}
				parentObject.put("milestone_members", memberArr);
				
				if(response.getMilestoneFollowers() != null){
					memberArr = new JSONArray();
					memberArr = new JSONArray();
					memberIt = response.getMilestoneFollowers().iterator();
					while(memberIt.hasNext()){
						userJSON = new JSONObject();
						userBean = memberIt.next();
						userJSON.put("userName", userBean.getUserName());
						userJSON.put("firstName", userBean.getFirstName());
						userJSON.put("lastName", userBean.getLastName());
						userJSON.put("profile_picture", Constants.BASE_URL+Constants.PROFILE_PICTURE_URI+userBean.getUserName());
						
						memberArr.add(userJSON);
					}
				}else{
					memberArr = new JSONArray();
				}
				parentObject.put("milestone_followers", memberArr);
				
//				sharedItemsIt = response.getSharedItems().iterator();
//				while(sharedItemsIt.hasNext()){
//					itemJSON = new JSONObject();
//					sharedItemBean = sharedItemsIt.next();
//					itemJSON.put("item_id", sharedItemBean.getItem_id());
//					if(sharedItemBean.getItem_type().equalsIgnoreCase("IMAGE"))
//						itemJSON.put("url", Constants.BASE_URL+sharedItemBean.getUrl());
//					else
//						itemJSON.put("url", sharedItemBean.getUrl());
//					itemJSON.put("item_type", sharedItemBean.getItem_type());
//					itemJSON.put("shared_by", sharedItemBean.getShared_by());
//					itemJSON.put("share_time", sharedItemBean.getShare_time());
//					
//					itemArr.add(itemJSON);
//				}
//				parentObject.put("milestone_items", itemArr);
				
				commentIt = response.getComments().iterator();
				while(commentIt.hasNext()){
					commentBean = commentIt.next();
					commentJSON = new JSONObject();
					commentJSON.put("comment", commentBean.getComment());
					commentJSON.put("commented_by", commentBean.getCommented_by());
					commentJSON.put("fname", commentBean.getFname());
					commentJSON.put("lname", commentBean.getLname());
					commentJSON.put("comment_time", commentBean.getComment_time());
					commentJSON.put("profile_picture", Constants.BASE_URL+Constants.PROFILE_PICTURE_URI+commentBean.getCommented_by());
					
					commentArr.add(commentJSON);
				}
				parentObject.put("comments", commentArr);
			}else{
				parentObject.put("error_text", response.getError_text());
			}
		}catch(Exception ex){
			new TVGException("Error in generating response for view milestone : "+ex);
		}
		return parentObject;
	}
	
//	public static JSONObject custVoteResponse(ResponseStatusBean responseStatus){
//		JSONObject parentObject = new JSONObject();
//		try{
//			parentObject.put("return_code", ""+responseStatus.getReturnCode());
//			if(responseStatus.getReturnCode() == 0){
//				parentObject.put("response", "Your vote has been custed sucessfully.");
//			}else{
//				parentObject.put("error_text", responseStatus.getErrorText());
//			}
//		}catch(Exception ex){
//			new TVGException("Error in generating response for milestone creation : "+ex);
//		}
//		return parentObject;
//	}
	
	public static JSONObject milestoneContentsResponse(List<ItemDetailsBean> itemList){
		JSONObject parentObject = new JSONObject();
		JSONArray itemArr = new JSONArray();
		JSONObject itemJSON;
		Iterator<ItemDetailsBean> sharedItemsIt;
		ItemDetailsBean sharedItemBean;
		try{
			sharedItemsIt = itemList.iterator();
			while(sharedItemsIt.hasNext()){
				itemJSON = new JSONObject();
				sharedItemBean = sharedItemsIt.next();
				itemJSON.put("item_id", sharedItemBean.getItem_id());
				if(!sharedItemBean.getUrl().contains("http"))
					itemJSON.put("url", Constants.BASE_URL+sharedItemBean.getUrl());
				else
					itemJSON.put("url", sharedItemBean.getUrl());
				itemJSON.put("item_type", sharedItemBean.getItem_type());
				itemJSON.put("shared_by", sharedItemBean.getShared_by());
				itemJSON.put("share_time", sharedItemBean.getShare_time());
				itemJSON.put("total_vote", sharedItemBean.getVoteCount());
				itemJSON.put("total_comment", sharedItemBean.getCommentCount());
				
				itemArr.add(itemJSON);
			}
			parentObject.put("milestone_items", itemArr);
		}catch(Exception ex){
			new TVGException("Error in generating response for milestone contents : "+ex);
		}
		return parentObject;
	}
	
	public static JSONObject uploadContentResponse(ResponseStatusBean responseStatus){
		JSONObject parentObject = new JSONObject();
		try{
			parentObject.put("return_code", ""+responseStatus.getReturnCode());
			if(responseStatus.getReturnCode() == 0){
				parentObject.put("response", "Content has been uploaded sucessfully.");
			}else{
				parentObject.put("error_text", responseStatus.getErrorText());
			}
		}catch(Exception ex){
			new TVGException("Error in generating response for milestone creation : "+ex);
		}
		return parentObject;
	}
	
}
