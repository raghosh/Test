package com.tvg.server.response;

import java.util.Iterator;
import java.util.List;

import com.tvg.server.constant.Constants;
import com.tvg.server.exception.TVGException;
import com.tvg.server.util.bean.CategoryBean;
import com.tvg.server.util.bean.MilestoneBean;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class ViewCategoryResponse {
	
	public static JSONObject generateCategoryResponse(List<CategoryBean> catList){
		JSONObject parentObject = new JSONObject();
		Iterator<CategoryBean> catIt;
		CategoryBean catBean;
		JSONArray catArr = new JSONArray();
		JSONObject catJSON;
		try{
			catIt = catList.iterator();
			while(catIt.hasNext()){
				catBean = catIt.next();
				catJSON = new JSONObject();
				catJSON.put("category_id", catBean.getId());
				catJSON.put("category_name", catBean.getCategory_name());
				
				catArr.add(catJSON);
			}
			parentObject.put("categories", catArr);
		}catch(Exception ex){
			new TVGException("Error in generating view category response : "+ex);
		}
		return parentObject;
	}

	public static JSONObject generateCategoryDetailsResponse(CategoryBean response){
		JSONObject parentObject = new JSONObject();
		Iterator<MilestoneBean> milestoneIt;
		MilestoneBean milestoneBean;
		JSONArray milestoneArr = new JSONArray();
		try{
			parentObject.put("category_id", response.getId());
			parentObject.put("category_name", response.getCategory_name());
			milestoneIt = response.getMilestones().iterator();
			while(milestoneIt.hasNext()){
				JSONObject milestoneJSON = new JSONObject();
				milestoneBean = milestoneIt.next();
				milestoneJSON.put("id", milestoneBean.getMilestoneId());
				milestoneJSON.put("name", milestoneBean.getMilestone_name());
				milestoneJSON.put("description", milestoneBean.getDescription());
				
				if(milestoneBean.getCover_image() != null){
					if(milestoneBean.getCover_image().contains("http"))
						milestoneJSON.put("cover_image", milestoneBean.getCover_image());
					else
						milestoneJSON.put("cover_image", Constants.BASE_URL+milestoneBean.getCover_image());
				}else{
					milestoneJSON.put("cover_image", Constants.BASE_URL+Constants.SHARE_IMAGE_URI+Constants.UID+Constants.NO_IMAGE);
				}
				
				milestoneArr.add(milestoneJSON);
			}
			parentObject.put("milestones", milestoneArr);
		}catch(Exception ex){
			new TVGException("Error in generating view category details response : "+ex);
		}
		return parentObject;
	}
	
}
