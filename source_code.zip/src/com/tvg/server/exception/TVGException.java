package com.tvg.server.exception;

import com.tvg.server.logs.Log;

/**
 * 
 * Custom exception class
 *
 */
public class TVGException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8090091135384817385L;

	public TVGException() {
		super();
	}

	public TVGException(String cause) {
		super(cause);
		Log.printWSLogErr(cause);
	}

}
