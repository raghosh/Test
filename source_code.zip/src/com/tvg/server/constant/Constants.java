package com.tvg.server.constant;

/**
 * 
 * This class contains all the constants
 *
 */
public class Constants {

	public static final String SERVER_ERROR = "Internal Server Error.";
	public static final String MISSING_REQUIRED_PARAM = "Missing required param : ";
	public static final String BASE_IMAGE_PATH = "C:/TVG";
	public static final String PROFILE_PICTURE_PATH = "profile";
	public static final String SHARED_MILESTONE_PATH = "milestone";
	public static final String SHARED_IMAGE_PATH = "image";
	public static final String SHARED_VIDEO_PATH = "video";
	public static final String COMMON_IMAGE_PATH = "common";
	public static final String NO_MILESTONE_IMAGE = "no_milestoneimg.jpg";
	public static final String BASE_URL = "http://localhost:8080/";
	public static final String PROFILE_PICTURE_URI = "tvgserver/jaxrs/image/profile?userName=";
	public static final String SHARE_IMAGE_URI = "tvgserver/jaxrs/image/milestone/image?";
	public static final String SHARE_VIDEO_URI = "tvgserver/jaxrs/image/milestone/video?";
	public static final String UID = "uid=";
	public static final String MID = "&mid=";
	public static final String NO_IMAGE = "no-image";
	public static final String[] VALID_IMAGE_EXTENSIONS = new String[] { "jpg", "jpeg", "gif", "png", "mp4", "mov" };
	public static final String[] VALID_CONTENT_TYPES = new String[] { "image/gif", "image/jpeg", "image/jpg", "image/png", "image/svg", "image/pjpeg",  "video/mpeg", "video/mp4", "video/ogg", "video/quicktime", "video/webm", "video/x-matroska", "video/x-ms-wmv", "video/x-flv" };
	public static final String[] VALID_IMAGE_TYPES = new String[] { "image/gif", "image/jpeg", "image/jpg", "image/png", "image/svg", "image/pjpeg" };
	public static final String[] VALID_VIDEO_TYPES = new String[] { "video/mpeg", "video/mp4", "video/ogg", "video/quicktime", "video/webm", "video/x-matroska", "video/x-ms-wmv", "video/x-flv"};
	public static final String HTTP_HEAD_REQUEST = "HEAD";
	public static final String IMAGE = "image";
	public static final String VIDEO = "video";
	public static final String INVALID = "invalid";
}
