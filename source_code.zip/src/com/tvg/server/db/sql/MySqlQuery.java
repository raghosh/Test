package com.tvg.server.db.sql;

/**
 * 
 * This class contains all database queries
 *
 */
public class MySqlQuery {

	public static final String REGISTER_USER = "INSERT INTO tb_user_info (user_id, password, fname, mname, lname, sex) " +
													"VALUES (?, ?, ?, ?, ?, ?)";
	public static final String CHECK_USER = "SELECT COUNT(*) AS userCount FROM tb_user_info WHERE user_id = ?";
	public static final String USER_LOGIN = "SELECT fname, mname, lname, sex from tb_user_info WHERE user_id = ? AND password = ?";
	public static final String GEL_ALL_CATEGORIES = "SELECT id, category_name FROM tb_milestone_category";
	public static final String CREATE_MILESTONE = "INSERT INTO tb_milestone (milestone_id, display_name, description, category, tags, coverImage, created_by) " +
													"VALUES (?, ?, ?, ?, ?, ?, ?)";
	public static final String ALL_MILESTONES_SUBSET = "SELECT milestone_id, display_name, description FROM tb_milestone LIMIT 0, 5";
	public static final String MILESTONES_SUBSET = "SELECT milestone_id, display_name, description FROM tb_milestone WHERE category = ? LIMIT 0, 5";
	public static final String SHARE_ITEMS = "INSERT INTO tb_shared_items (item_id, url, title, item_type, shared_by, milestone_id) VALUES (?, ?, ?, ?, ?, ?)";
	public static final String ALL_CATEGORY_DETAILS = "SELECT milestone_id, display_name, description FROM tb_milestone";
	public static final String ALL_CATEGORIES = "SELECT id, category_name FROM tb_milestone_category";
	public static final String CATEGORY_DETAILS = "SELECT milestone_id, display_name, description FROM tb_milestone WHERE category = ?";
	public static final String VIEW_MILESTONE_DETAILS = "SELECT milestone_id, display_name, description, category_name, coverImage, created_by FROM tb_milestone m, tb_milestone_category mc WHERE m.category = mc.id AND milestone_id = ?";
	public static final String MILESTONE_IMAGE_COUNT = "SELECT COUNT(*) AS imageCount FROM tb_shared_items WHERE item_type = 2 AND milestone_id = ?";
	public static final String FETCH_MILESTONE_IMAGE = "SELECT url FROM tb_shared_items WHERE item_type = 2 AND milestone_id = ?";
	public static final String FETCH_TOP_VOTED_IMAGE = "SELECT url FROM tb_shared_items WHERE item_type = 2 AND milestone_id = ? ORDER BY vote_count desc LIMIT 0,1";
	public static final String VIEW_MILESTONE_ITEMS = "SELECT item_id, url, type, shared_by, share_time FROM tb_shared_items si, tb_item_type it WHERE si.item_type = it.id AND milestone_id = ? AND type != 'URL' ORDER BY share_time";
	public static final String ITEM_VOTE_COUNT = "SELECT COUNT(*) as voteCount FROM tb_item_vote WHERE item_id = ?";
	public static final String ITEM_COMMENT_COUNT = "SELECT COUNT(*) as commentCount FROM tb_item_comments WHERE item = ?";
	public static final String VIEW_MILESTONE_LINKS = "SELECT item_id, url, type, shared_by, share_time FROM tb_shared_items si, tb_item_type it WHERE si.item_type = it.id AND milestone_id = ? AND type = 'URL' ORDER BY share_time";
	public static final String VIEW_MILESTONE_FOLLOWERS = "SELECT followed_by, fname, lname FROM tb_follow_milestone fm, tb_user_info ui WHERE ui.user_id = fm.followed_by AND milestone_id = ?";
	public static final String VIEW_MILESTONE_MEMBERS = "SELECT milestone_id, member, fname, lname FROM tb_milestone_member mm, tb_user_info ui WHERE ui.user_id = mm.member AND milestone_id = ?";
	public static final String INSERT_MILESTONE_MEMBER = "INSERT INTO tb_milestone_member (milestone_id, member) VALUES (?, ?)";
	public static final String CUST_MILESTONE_VOTE = "INSERT INTO tb_milestone_vote (milestone_id, voted_by, vote) VALUES (?, ?, ?)";
	public static final String CHECK_MILESTONE_VOTE = "SELECT vote FROM tb_milestone_vote WHERE milestone_id = ? AND voted_by = ?";
	public static final String UPDATE_MILESTONE_VOTE = "UPDATE tb_milestone_vote SET vote = ? WHERE milestone_id = ? AND voted_by = ?";
	public static final String FOLLOW_MILESTONE = "INSERT INTO tb_follow_milestone (milestone_id, followed_by) VALUES (?, ?)";
	public static final String UNFOLLOW_MILESTONE = "DELETE FROM tb_follow_milestone WHERE milestone_id = ? AND followed_by = ?";
	public static final String CHECK_FOLLOW_MILESTONE = "SELECT COUNT(*) AS cnt FROM tb_follow_milestone WHERE milestone_id = ? AND followed_by = ?";
	public static final String JOIN_MILESTONE = "INSERT INTO tb_milestone_member (milestone_id, member) VALUES (?, ?)";
	public static final String LEAVE_MILESTONE = "DELETE FROM tb_milestone_member WHERE milestone_id = ? AND member = ?";
	public static final String CHECK__MILESTONE_MEMBER = "SELECT COUNT(*) AS cnt FROM tb_milestone_member WHERE milestone_id = ? AND member = ?";
	public static final String POST_MILESTONE_COMMENT = "INSERT INTO tb_milestone_comments (milestone, comment, commented_by) VALUE (?, ?, ?)";
	public static final String VIEW_MILESTONE_COMMENT = "SELECT milestone, comment, commented_by, fname, lname, comment_time FROM tb_milestone_comments mc, tb_user_info ui WHERE mc.commented_by = ui.user_id AND milestone = ?";
	
	public static final String CUST_ITEM_VOTE = "INSERT INTO tb_item_vote (item_id, vote, milestone_id, voted_by) VALUES (?, ?, ?, ?)";
	public static final String INCREASE_VOTE_COUNT = "UPDATE tb_shared_items SET vote_count = vote_count + 1 WHERE item_id = ?";
	public static final String CHECK_ITEM_VOTE = "SELECT vote FROM tb_item_vote WHERE item_id = ? AND voted_by = ?";
	public static final String UPDATE_ITEM_VOTE = "UPDATE tb_item_vote SET vote = ? WHERE item_id = ? AND voted_by = ?";
	public static final String POST_ITEM_COMMENT = "INSERT INTO tb_item_comments (item, comment, commented_by) VALUE (?, ?, ?)";
	public static final String INCREASE_COMMENT_COUNT = "UPDATE tb_shared_items SET comment_count = comment_count + 1 WHERE item_id = ?";
	
	public static final String GET_USER_INFO = "SELECT user_id, fname, mname, lname, sex FROM tb_user_info WHERE user_id = ?";
	public static final String GET_FOLLOWED_CATEGORY = "SELECT category FROM tb_follow_category WHERE followed_by = ?";
	public static final String GET_FOLLOWED_USERS = "SELECT followed_by, fname, lname FROM tb_follow_user fu, tb_user_info ui WHERE fu.followed_by = ui.user_id AND userName = ?";
	public static final String CHANGE_PASSWORD = "UPDATE tb_user_info SET password = ? WHERE user_id = ?";
	public static final String CHANGE_EMAIL = "UPDATE tb_user_info SET email = ? WHERE user_id = ?";
	public static final String FOLLOW_USER = "INSERT INTO tb_follow_user (userName, followed_by) VALUES (?, ?)";
	public static final String USER_MILESTONES = "SELECT milestone_id, display_name, description, category_name, created_by FROM tb_milestone m, tb_milestone_category mc " +
													"WHERE m.category = mc.id  AND (created_by = ? OR milestone_id IN (SELECT milestone_id FROM tb_follow_milestone WHERE followed_by = ?))";
	public static final String CHECK_EMAIL = "SELECT COUNT(*) AS emailCount FROM tb_user_info WHERE email = ?";
}
