package com.tvg.server.db.util;

/**
 * 
 * This class contains all database parameters. 
 *
 */
public class DBConstants {

	public static final String DBUSERID = "root";
	public static final String DBPASSWD = "objectsol";
	public static final String DATABASE = "tvg";
    public static final String DRIVER = "com.mysql.jdbc.Driver";
    public static final String DBURL = "jdbc:mysql://localhost:3306/" + DATABASE;
	
}
