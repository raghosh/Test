package com.tvg.server.db.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.tvg.server.exception.TVGException;

/**
 *	This class is responsible for Database connection  
 */
public class DBConnection {

	Connection connection = null;
	
	/**
	 * 
	 * @return Connection object
	 */
	public Connection openConnection() {
        try {
            Class.forName(DBConstants.DRIVER).newInstance();
            connection = DriverManager.getConnection(DBConstants.DBURL, DBConstants.DBUSERID, DBConstants.DBPASSWD);
        } catch (SQLException sql) {
            new TVGException("SQLException in MysqlConnection openConnection : " + sql);
        } catch (Exception ex) {
            new TVGException("Exception in MysqlConnection openConnection : " + ex);
        }
        return connection;
    }
	
	/**
	 * 
	 * @param con
	 */
	public void closeConnection(Connection con){
        connection = con;
        try{
            connection.close();
        }catch(NullPointerException npe){
            new TVGException("NullPointerException in MysqlConnection cloceConnection : " + npe);
        }catch (Exception ex) {
            new TVGException("Exception in MysqlConnection cloceConnection : " + ex);
        }
    }
	
}
