package com.tvg.server.service;

import java.util.List;

import com.tvg.server.util.bean.CategoryBean;

public interface ViewCategoryService {

	public List<CategoryBean> getAllCategories();
	public CategoryBean getAllCategoryDetails();
	public CategoryBean getCategoryDetails(int categoryId);
	
}
