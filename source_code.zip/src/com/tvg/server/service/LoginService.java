package com.tvg.server.service;

import com.tvg.server.util.bean.LoginResponseBean;

public interface LoginService {
	public LoginResponseBean getLoginData(String userName, String password);
}
