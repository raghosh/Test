package com.tvg.server.service;

public interface ShareItemService {

	public boolean sharePicture(String itemId, String shared_by, String title,
			String milestone_id, String itemType, String contentType, String extention, String mimeType, String url);
	public boolean shareURL(String itemId, String shared_by, String title, String url, String milestone_id);
	public boolean custItemVote(String itemId, String milestoneId, String userName, int vote);
	public boolean postComment(String itemId, String uid, String comment);
	
}
