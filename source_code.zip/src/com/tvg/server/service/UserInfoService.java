package com.tvg.server.service;

import java.util.List;

import com.tvg.server.util.bean.MilestoneBean;
import com.tvg.server.util.bean.ResponseStatusBean;
import com.tvg.server.util.bean.UserInfoBean;

public interface UserInfoService {

	public UserInfoBean getUserInfo(String uid);
	public boolean changePassword(String userId, String newPass);
	public boolean followUser(String userId, String followed_by);
	public List<MilestoneBean> getUserMilestone(String userId);
	public ResponseStatusBean checkEmail(String email);
	public boolean changeEmail(String userId, String email);
}
