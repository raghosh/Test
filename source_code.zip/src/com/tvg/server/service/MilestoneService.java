package com.tvg.server.service;

import java.util.List;

import com.tvg.server.util.bean.ItemDetailsBean;
import com.tvg.server.util.bean.MilestoneDetailsBean;
import com.tvg.server.util.bean.ResponseStatusBean;

public interface MilestoneService {

	public ResponseStatusBean createMilestone(String milestone_id, String display_name, String description, int category, 
			String tags, String itemId, String url, String title, String contentType, String itemType, String created_by, String mimeType, String extention);
	
	public MilestoneDetailsBean viewMilestone(String mid, String uid);
	
	public ResponseStatusBean custVote(String milestoneId, String userName, int vote);
	
	public ResponseStatusBean followMilestone(String milestoneId, String userName);
	
	public ResponseStatusBean joinMilestone(String milestoneId, String userName);
	
	public boolean postComment(String mid, String uid, String comment);
	
	public List<ItemDetailsBean> viewContents(String mid);
	
	public List<ItemDetailsBean> viewLinks(String mid);
	
}
