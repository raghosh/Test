package com.tvg.server.service;

import com.tvg.server.util.bean.ResponseStatusBean;
/**
 * 
 * Interface for Registration services
 *
 */
public interface RegistrationService {
	/**
	 * 
	 * @param request
	 * @return
	 */
	public ResponseStatusBean registerUser(String userName, String password, String firstName, String midName, 
			String lastName, String sex);
	
	/**
	 * 
	 * @param request
	 * @return
	 */
	public ResponseStatusBean checkUser(String userName);
}
