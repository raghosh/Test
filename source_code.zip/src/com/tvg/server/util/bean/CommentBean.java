package com.tvg.server.util.bean;

public class CommentBean {

	private String comment;
	private String commented_by;
	private String fname;
	private String lname;
	private String comment_time;

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getCommented_by() {
		return commented_by;
	}

	public void setCommented_by(String commented_by) {
		this.commented_by = commented_by;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getComment_time() {
		return comment_time;
	}

	public void setComment_time(String comment_time) {
		this.comment_time = comment_time;
	}

}
