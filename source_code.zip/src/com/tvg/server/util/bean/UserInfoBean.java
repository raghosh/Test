package com.tvg.server.util.bean;

import java.util.List;

public class UserInfoBean {

	private String userName;
	private String firstName;
	private String midName;
	private String lastName;
	private String sex;
	private List<Integer> followedCategoryList;
	private List<UserInfoBean> follwedUserList;
	private List<CategoryBean> categoryList;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getMidName() {
		return midName;
	}

	public void setMidName(String midName) {
		this.midName = midName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public List<Integer> getFollowedCategoryList() {
		return followedCategoryList;
	}

	public void setFollowedCategoryList(List<Integer> followedCategoryList) {
		this.followedCategoryList = followedCategoryList;
	}

	public List<UserInfoBean> getFollwedUserList() {
		return follwedUserList;
	}

	public void setFollwedUserList(List<UserInfoBean> follwedUserList) {
		this.follwedUserList = follwedUserList;
	}

	public List<CategoryBean> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<CategoryBean> categoryList) {
		this.categoryList = categoryList;
	}

}
