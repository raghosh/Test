package com.tvg.server.util.bean;

import java.util.List;

public class LoginResponseBean {

	private int return_code;
	private String userName;
	private String firstName;
	private String midName;
	private String lastName;
	private String sex;
	private String error_text;
	private List<CategoryBean> categories;

	public int getReturn_code() {
		return return_code;
	}

	public void setReturn_code(int return_code) {
		this.return_code = return_code;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMidName() {
		return midName;
	}

	public void setMidName(String midName) {
		this.midName = midName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getError_text() {
		return error_text;
	}

	public void setError_text(String error_text) {
		this.error_text = error_text;
	}

	public List<CategoryBean> getCategories() {
		return categories;
	}

	public void setCategories(List<CategoryBean> categories) {
		this.categories = categories;
	}

}
