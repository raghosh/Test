package com.tvg.server.util.bean;

public class ItemDetailsBean {

	private String item_id;
	private String url;
	private String item_type;
	private String shared_by;
	private String share_time;
	private int voteCount;
	private int commentCount;

	public String getItem_id() {
		return item_id;
	}

	public void setItem_id(String item_id) {
		this.item_id = item_id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getItem_type() {
		return item_type;
	}

	public void setItem_type(String item_type) {
		this.item_type = item_type;
	}

	public String getShared_by() {
		return shared_by;
	}

	public void setShared_by(String shared_by) {
		this.shared_by = shared_by;
	}

	public String getShare_time() {
		return share_time;
	}

	public void setShare_time(String share_time) {
		this.share_time = share_time;
	}

	public int getVoteCount() {
		return voteCount;
	}

	public void setVoteCount(int voteCount) {
		this.voteCount = voteCount;
	}

	public int getCommentCount() {
		return commentCount;
	}

	public void setCommentCount(int commentCount) {
		this.commentCount = commentCount;
	}

}
