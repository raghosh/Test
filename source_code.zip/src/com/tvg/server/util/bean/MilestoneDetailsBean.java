package com.tvg.server.util.bean;

import java.util.List;

public class MilestoneDetailsBean {

	private int return_code;
	private String error_text;
	private String milestone_id;
	private String display_name;
	private String description;
	private String category_name;
	private String created_by;
	private int vote;
	private boolean member;
	private boolean following;
	private List<UserInfoBean> milestoneMembers;
	private List<UserInfoBean> milestoneFollowers;
	List<ItemDetailsBean> sharedItems;
	List<CommentBean> comments;

	public int getReturn_code() {
		return return_code;
	}

	public void setReturn_code(int return_code) {
		this.return_code = return_code;
	}

	public String getError_text() {
		return error_text;
	}

	public void setError_text(String error_text) {
		this.error_text = error_text;
	}

	public String getMilestone_id() {
		return milestone_id;
	}

	public void setMilestone_id(String milestone_id) {
		this.milestone_id = milestone_id;
	}

	public String getDisplay_name() {
		return display_name;
	}

	public void setDisplay_name(String display_name) {
		this.display_name = display_name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public int getVote() {
		return vote;
	}

	public void setVote(int vote) {
		this.vote = vote;
	}

	public boolean isMember() {
		return member;
	}

	public void setMember(boolean member) {
		this.member = member;
	}

	public boolean isFollowing() {
		return following;
	}

	public void setFollowing(boolean following) {
		this.following = following;
	}

	public List<UserInfoBean> getMilestoneMembers() {
		return milestoneMembers;
	}

	public void setMilestoneMembers(List<UserInfoBean> milestoneMembers) {
		this.milestoneMembers = milestoneMembers;
	}

	public List<UserInfoBean> getMilestoneFollowers() {
		return milestoneFollowers;
	}

	public void setMilestoneFollowers(List<UserInfoBean> milestoneFollowers) {
		this.milestoneFollowers = milestoneFollowers;
	}

	public List<ItemDetailsBean> getSharedItems() {
		return sharedItems;
	}

	public void setSharedItems(List<ItemDetailsBean> sharedItems) {
		this.sharedItems = sharedItems;
	}

	public List<CommentBean> getComments() {
		return comments;
	}

	public void setComments(List<CommentBean> comments) {
		this.comments = comments;
	}

}
