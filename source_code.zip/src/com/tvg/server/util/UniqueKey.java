package com.tvg.server.util;

public class UniqueKey {

	public static String randomstring(int lo, int hi) {
		int n = rand(lo, hi);
		byte b[] = new byte[n];
		for (int i = 0; i < n; i++)
			b[i] = (byte) rand('a', 'z');
		return new String(b, 0);
	}

	private static int rand(int lo, int hi) {
		java.util.Random rn = new java.util.Random();
		int n = hi - lo + 1;
		int i = rn.nextInt(n);
		if (i < 0)
			i = -i;
		return lo + i;
	}

	public static String randomstring() {
		return randomstring(1, 3);
	}

	public static String currentTime(int pos) {
		String currTime = Long.toString(System.currentTimeMillis());
		if (pos == 1)
			currTime = currTime.substring(0, (currTime.length() / 2));
		else
			currTime = currTime.substring((currTime.length() / 2), (currTime
					.length() - 1));

		return currTime;
	}

	public static String getKey() {
		return randomstring() + currentTime(1) + randomstring()
				+ currentTime(2);
	}
	
}
