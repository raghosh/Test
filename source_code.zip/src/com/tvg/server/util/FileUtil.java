package com.tvg.server.util;

import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.activation.MimetypesFileTypeMap;

import org.apache.commons.lang3.StringUtils;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.tvg.server.constant.Constants;
import com.tvg.server.exception.TVGException;

public class FileUtil {

	public static String getFileExtention(String  filename){
		String extension = "";
		try{
			extension = filename.substring(filename.lastIndexOf(".") + 1, filename.length());
		}catch(Exception ex){
			new TVGException("Exception in getFileExtention : "+ex);
		}
		return extension.toLowerCase();
	}
	
	public static String getFileMimeType(FormDataContentDisposition fileDetail){
		String mimeType = "";
		try{
			File f = new File(Constants.BASE_IMAGE_PATH+File.separator+fileDetail.getFileName());
			mimeType = new MimetypesFileTypeMap().getContentType(f);
		}catch(Exception ex){
			new TVGException("Exception in getFileMimeType : "+ex);
		}
		return mimeType;
	}
	
	public static String getItemType(String  mimeType, String extention){
		String itemType = Constants.INVALID;
		try{
			if(mimeType.equals("application/octet-stream")){
				// extensions mp4, 3gp, 3g2, m4v, png
				if(extention.equals("mp4")){
					itemType = Constants.VIDEO;
				}else if(extention.equals("3gp")){
					itemType = Constants.VIDEO;
				}else if(extention.equals("3g2")){
					itemType = Constants.VIDEO;
				}else if(extention.equals("m4v")){
					itemType = Constants.VIDEO;
				}else if(extention.equals("png")){
					itemType = Constants.IMAGE;
				}else{
					itemType = Constants.INVALID;
				}
			}else if(mimeType.equals("video/quicktime")){
				// extensions mov
				if(extention.equals("mov")){
					itemType = Constants.VIDEO;
				}else{
					itemType = Constants.INVALID;
				}
			}else if(mimeType.equals("image/gif")){
				// extensions gif
				if(extention.equals("gif")){
					itemType = Constants.IMAGE;
				}else{
					itemType = Constants.INVALID;
				}
			}else if(mimeType.equals("image/jpeg")){
				// extensions jpeg, jpg
				if(extention.equals("jpeg")){
					itemType = Constants.IMAGE;
				}else if(extention.equals("jpg")){
					itemType = Constants.IMAGE;
				}else{
					itemType = Constants.INVALID;
				}
			}else if(mimeType.equals("image/pjpeg")){
				// extensions jpeg, jpe, jpg
				if(extention.equals("jpeg")){
					itemType = Constants.IMAGE;
				}else if(extention.equals("jpg")){
					itemType = Constants.IMAGE;
				}else if(extention.equals("jpe")){
					itemType = Constants.IMAGE;
				}else{
					itemType = Constants.INVALID;
				}
			}
		}catch(Exception ex){
			new TVGException("Exception in getFileExtention : "+ex);
		}
		return itemType;
	}	
	
	public static boolean checkUrl(final String url) {
//        if (!StringUtils.endsWithAny(url, Constants.VALID_IMAGE_EXTENSIONS)) { // example
//            System.out.println("No valid extension");

            try {
                HttpURLConnection.setFollowRedirects(false);
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(url).openConnection();
                httpURLConnection.setRequestMethod(Constants.HTTP_HEAD_REQUEST);

                return (httpURLConnection.getResponseCode() == HttpURLConnection.HTTP_OK && StringUtils.endsWithAny(httpURLConnection
                        .getContentType(), Constants.VALID_CONTENT_TYPES));
            } catch (Exception ex) {
                new TVGException("Exception in checkUrl : "+ex );
                return false;
            }
//        } else {
//            System.out.println("Valid extension");
//            return true;
//        }
    }
	
	public static String getURLItemType(String  url){
		String itemType = Constants.INVALID;
		try {
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(url).openConnection();
            httpURLConnection.setRequestMethod(Constants.HTTP_HEAD_REQUEST);
            
            if( StringUtils.endsWithAny(httpURLConnection.getContentType(), Constants.VALID_IMAGE_TYPES)){
            	itemType = Constants.IMAGE;
            }else if( StringUtils.endsWithAny(httpURLConnection.getContentType(), Constants.VALID_VIDEO_TYPES)){
            	itemType = Constants.VIDEO;
            }
            
        } catch (Exception ex) {
        	 new TVGException("Exception in getURLItemType : "+ex );
        }
		return itemType;
	}
	
	public static boolean checkValidUrl(final String url) {        
		try {
			HttpURLConnection.setFollowRedirects(false);
			HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(url).openConnection();
			httpURLConnection.setRequestMethod(Constants.HTTP_HEAD_REQUEST);

			return (httpURLConnection.getResponseCode() == HttpURLConnection.HTTP_OK);
		} catch (Exception ex) {
			 new TVGException("Exception in checkValidUrl : "+ex );
			return false;
		}
        
    }
	
}
