package com.tvg.server.util;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import javax.imageio.ImageIO;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.tvg.server.constant.Constants;
import com.tvg.server.exception.TVGException;
import com.tvg.server.util.bean.ContentUploadBean;

public class UploadContent {

	public static ContentUploadBean upload(InputStream uploadedInputStream, FormDataContentDisposition fileDetail, String url, String milestone_id){
		ContentUploadBean contentBean;
		String mimeType, extention, itemType, contentType, item_id;
		try{
			item_id = "I_"+UniqueKey.getKey();
			if(uploadedInputStream != null && fileDetail.getFileName() != null && !fileDetail.getFileName().equals("")){
				mimeType = FileUtil.getFileMimeType(fileDetail);
				extention = FileUtil.getFileExtention(fileDetail.getFileName());
				itemType = FileUtil.getItemType(mimeType, extention);
				contentType = itemType;
				if(!itemType.equals(Constants.INVALID)){
					String path = Constants.BASE_IMAGE_PATH;
					File folder = new File(path);
					if(!folder.exists())
						folder.mkdir();
					
					path = path+File.separator+Constants.SHARED_MILESTONE_PATH;
					
					folder = new File(path);
					if(!folder.exists())
						folder.mkdir();
					
					path = path+File.separator+milestone_id;
					
					folder = new File(path);
					if(!folder.exists())
						folder.mkdir();
					
					if(itemType.equals(Constants.IMAGE)){
						
						path = path+File.separator+Constants.SHARED_IMAGE_PATH;
						
						folder = new File(path);
						if(!folder.exists())
							folder.mkdir();
						
						path = path+File.separator+item_id+".jpg";
						
						BufferedImage bImageFromConvert = ImageIO.read(uploadedInputStream);
	   					 
						ImageIO.write(bImageFromConvert, "jpg", new File(path));
						contentBean = new ContentUploadBean();
						contentBean.setReturnCode(0);
					}else if (itemType.equals(Constants.VIDEO)){
						
						path = path+File.separator+Constants.SHARED_VIDEO_PATH;
						
						folder = new File(path);
						if(!folder.exists())
							folder.mkdir();
						
						path = path+File.separator+item_id+"."+extention;
						
						OutputStream out = new FileOutputStream(new File(path));
						int read = 0;
						byte[] bytes = new byte[1024];
			 
						out = new FileOutputStream(new File(path));
						while ((read = uploadedInputStream.read(bytes)) != -1) {
							out.write(bytes, 0, read);
						}
						out.flush();
						out.close();
						contentBean = new ContentUploadBean();
						contentBean.setReturnCode(0);
					}else{
						contentBean = new ContentUploadBean();
						contentBean.setReturnCode(1);
						contentBean.setErrorText("Invalid file format");
					}
					contentBean.setContentType(contentType);
					contentBean.setItemType(itemType);
					contentBean.setMimeType(mimeType);
					contentBean.setExtention(extention);
					contentBean.setItem_id(item_id);
				}else{
					contentBean = new ContentUploadBean();
					contentBean.setReturnCode(1);
					contentBean.setErrorText("Invalid file format");
				}				
				
			}else{
				boolean validURL = FileUtil.checkUrl(url);
				if(validURL){
					itemType = FileUtil.getURLItemType(url);
					contentType = "url";
					
					contentBean = new ContentUploadBean();
					contentBean.setContentType(contentType);
					contentBean.setItemType(itemType);
					contentBean.setItem_id(item_id);
					contentBean.setReturnCode(0);
				}else{
					itemType = "";
					contentBean = new ContentUploadBean();
					contentBean.setReturnCode(1);
					contentBean.setErrorText("Invalid file format");
				}
			}
		}catch(Exception ex){
			contentBean = new ContentUploadBean();
			contentBean.setReturnCode(1);
			contentBean.setErrorText("Invalid file format");
			new TVGException("Exception in UploadContent : "+ex);
		}
		return contentBean;
	}
	
}
