package com.tvg.server.logs;

import org.apache.log4j.Logger;

/**
 * 
 * Custom logger class
 *
 */
public class Log {

	static Logger logger=Logger.getLogger (Log.class);
	
	public static void printWSLogErr(String cause){	    
		logger.info("Exception from TVG Server:"); 
	    logger.error(cause); 
	}
	
}
