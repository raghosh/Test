package com.tvg.server.action;

import java.io.IOException;
import java.io.OutputStream;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.StreamingOutput;

import org.json.JSONObject;

import com.tvg.server.action.validate.ValidateRegisterationRequestParam;
import com.tvg.server.exception.TVGException;
import com.tvg.server.response.RegistrationResponse;
import com.tvg.server.service.RegistrationService;
import com.tvg.server.serviceImpl.RegistrationServiceImpl;
import com.tvg.server.util.bean.ResponseStatusBean;


@Path(value = "/registration")
public class RegistrationAction {	
	
	RegistrationService regService;
	
	public RegistrationAction(){
		regService  = new RegistrationServiceImpl();
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="register")
	public StreamingOutput registerUsers(@FormParam("userName") final String userName, @FormParam("password") final String password,
			 @FormParam("firstName") final String firstName, @FormParam("midName") final String midName, @FormParam("lastName") final String lastName, @FormParam("sex") final String sex){
		
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				JSONObject responseData = new JSONObject();
				ResponseStatusBean respStatus = new ResponseStatusBean();
				try{
					respStatus = ValidateRegisterationRequestParam.validateRegistrationParams(userName, password, firstName, lastName, sex);
					if(respStatus.getReturnCode() == 0){
						respStatus = regService.registerUser(userName, password, firstName, midName, lastName, sex);
					}
					
					responseData = RegistrationResponse.generateRegistrationResp(respStatus);
				}catch(Exception ex){
		    		new TVGException("Error in RegistrationAction : "+ex);
		    	}
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
			
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="check")
	public StreamingOutput checkUser(@FormParam("userName") final String userName){
		
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				JSONObject responseData = new JSONObject();
				try{					
		    		ResponseStatusBean respStatus = regService.checkUser(userName);
		    		
		    		responseData = RegistrationResponse.generateCheckUserResp(respStatus);
		    		
				}catch(Exception ex){
					new TVGException("Error in CheckUserAction : "+ex);
				}
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}
	
}
