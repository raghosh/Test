package com.tvg.server.action;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import net.sf.json.JSONObject;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.tvg.server.action.validate.ValidateMilestoneRequestParam;
import com.tvg.server.constant.Constants;
import com.tvg.server.exception.TVGException;
import com.tvg.server.response.MilestoneResponse;
import com.tvg.server.service.MilestoneService;
import com.tvg.server.serviceImpl.MilestoneServiceImpl;
import com.tvg.server.util.UniqueKey;
import com.tvg.server.util.UploadContent;
import com.tvg.server.util.bean.ContentUploadBean;
import com.tvg.server.util.bean.ItemDetailsBean;
import com.tvg.server.util.bean.MilestoneDetailsBean;
import com.tvg.server.util.bean.ResponseStatusBean;

@Path(value="/milestone")
public class MilestoneAction {
	
	private MilestoneService milestoneService;
	JSONObject responseData;
	
	public MilestoneAction(){
		milestoneService = new MilestoneServiceImpl();
	}
		

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Path(value="create")
	public StreamingOutput createMilestone(@FormParam("name") final String name, @FormParam("url") final String url, 
			@FormParam("description") final String description, @FormParam("category") final int category, 
			@FormParam("userName") final String userName, @FormParam("tags") final String tags, @FormParam("title") final String title,  
			@FormParam("file") final InputStream uploadedInputStream, @FormParam("file") final FormDataContentDisposition fileDetail){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				String milestone_id;
				ResponseStatusBean responseStatusBan;
				ContentUploadBean contentBean;
				try{					
					responseStatusBan = ValidateMilestoneRequestParam.validateCreateMilestoneParams(name, userName, url, fileDetail);
					if(responseStatusBan.getReturnCode() == 0){						
						milestone_id = "M_"+UniqueKey.getKey();
						
						contentBean = UploadContent.upload(uploadedInputStream, fileDetail, url, milestone_id);
						
						if(contentBean.getReturnCode() == 0){
							responseStatusBan = milestoneService.createMilestone(milestone_id, name, description, category, tags, contentBean.getItem_id(), 
									url, title, contentBean.getContentType(), contentBean.getItemType(), userName, contentBean.getMimeType(), contentBean.getExtention());
						}else{
							responseStatusBan.setReturnCode(1);
							responseStatusBan.setErrorText(contentBean.getErrorText());
						}
					}
					
				}catch(Exception ex){
					responseStatusBan = new ResponseStatusBean();
					responseStatusBan.setReturnCode(1);
					responseStatusBan.setErrorText(Constants.SERVER_ERROR);
					new TVGException("Exception in create milestone action : "+ex);
				}
				responseData = MilestoneResponse.createMilestoneResponse(responseStatusBan);
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="view")
	public StreamingOutput viewMilestone(@FormParam("mid") final String mid, @FormParam("uid") final String uid){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				MilestoneDetailsBean milestoneDetails;
				try{
					milestoneDetails = milestoneService.viewMilestone(mid, uid);
				}catch(Exception ex){
					milestoneDetails = new MilestoneDetailsBean();
					milestoneDetails.setReturn_code(1);
					milestoneDetails.setError_text(Constants.SERVER_ERROR);
					new TVGException("Exception in view milestone action : "+ex);
				}
				responseData = MilestoneResponse.viewMilestoneResponse(milestoneDetails);
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="vote")
	public Response custVote(@FormParam("mid") final String mid, @FormParam("uid") final String uid, @FormParam("vote") final int vote){
		ResponseStatusBean responseStatusBan;				
		try{
			responseStatusBan = milestoneService.custVote(mid, uid, vote);					
		}catch(Exception ex){
			responseStatusBan = new ResponseStatusBean();
			responseStatusBan.setReturnCode(1);
			responseStatusBan.setErrorText(Constants.SERVER_ERROR);
			new TVGException("Exception in vote milestone action : "+ex);
		}
//		responseData = MilestoneResponse.custVoteResponse(responseStatusBan);
		return Response.ok().build();
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="follow")
	public Response followMilestone(@FormParam("mid") String mid, @FormParam("uid") String uid){

		ResponseStatusBean responseStatusBan;
		try{
			responseStatusBan = milestoneService.followMilestone(mid, uid);					
		}catch(Exception ex){
			responseStatusBan = new ResponseStatusBean();
			responseStatusBan.setReturnCode(1);
			responseStatusBan.setErrorText(Constants.SERVER_ERROR);
			new TVGException("Exception in vote milestone action : "+ex);
		}
//		responseData = MilestoneResponse.custVoteResponse(responseStatusBan);	
		return Response.ok().build();
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="join")
	public Response joinMilestone(@FormParam("mid") final String mid, @FormParam("uid") final String uid){

		ResponseStatusBean responseStatusBan;
		try{
			responseStatusBan = milestoneService.joinMilestone(mid, uid);				
		}catch(Exception ex){
			responseStatusBan = new ResponseStatusBean();
			responseStatusBan.setReturnCode(1);
			responseStatusBan.setErrorText(Constants.SERVER_ERROR);
			new TVGException("Exception in vote milestone action : "+ex);
		}	
		return Response.ok().build();
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="comment")
	public Response milestoneComment(@FormParam("mid") final String mid, @FormParam("uid") final String uid, @FormParam("comment") final String comment){

		try{
			milestoneService.postComment(mid, uid, comment);				
		}catch(Exception ex){
			new TVGException("Exception in vote milestone action : "+ex);
		}	
		return Response.ok().build();
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="contents")
	public StreamingOutput viewContents(@FormParam("mid") final String mid){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				List<ItemDetailsBean> itemList;
				try{
					itemList = milestoneService.viewContents(mid);
				}catch(Exception ex){
					itemList = new ArrayList<ItemDetailsBean>();
					new TVGException("Exception in view milestone action : "+ex);
				}
				responseData = MilestoneResponse.milestoneContentsResponse(itemList);
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="links")
	public StreamingOutput viewLinks(@FormParam("mid") final String mid){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				List<ItemDetailsBean> itemList;
				try{
					itemList = milestoneService.viewLinks(mid);
				}catch(Exception ex){
					itemList = new ArrayList<ItemDetailsBean>();
					new TVGException("Exception in view milestone action : "+ex);
				}
				responseData = MilestoneResponse.milestoneContentsResponse(itemList);
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}	
	
}
