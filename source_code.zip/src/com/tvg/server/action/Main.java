package com.tvg.server.action;

import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.lang3.StringUtils;


public class Main {

	private static final String[] VALID_IMAGE_EXTENSIONS = new String[] { "jpg", "jpeg", "gif", "png", "svg", "mp4" };

    /* not completely */
    private static final String[] VALID_CONTENT_TYPES = new String[] { "image/gif", "image/jpeg", "image/jpg",
            "image/png", "image/svg" };

    private static final String HTTP_HEAD_REQUEST = "HEAD";

    public static void main(String[] args) {
        // Valid images
        System.out.println("Is URL valid? "
                + checkUrl("http://ads.myswitzerland.com/openads/www/images/3880eb25ffa1f3c87ca742aae22b5b16.gif"));
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("Is URL valid? "
                + checkUrl("http://ads.myswitzerland.com/openads/www/images/3880eb25ffa1f3c87ca742aae22b5b16"));

        // Invalid images
        System.out.println("Is URL valid? " + checkUrl("http://www.google.com"));
        System.out.println("");
        System.out.println("");
        System.out.println("");
        System.out.println("Is URL valid? " + checkUrl("https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRRRPIATEjxDlODqVaVYF86ZoDgupjhgjbCoVutH0sWS7oOG3XFdA"));
    }

    public static boolean checkUrl(final String url) {
        if (!StringUtils.endsWithAny(url, VALID_IMAGE_EXTENSIONS)) { // example
            System.out.println("No valid extension");

            try {
                HttpURLConnection.setFollowRedirects(false);
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(url).openConnection();
                httpURLConnection.setRequestMethod(HTTP_HEAD_REQUEST);

                System.out.println("HTTP code: " + httpURLConnection.getResponseCode());
                System.out.println("Respone content type: " + httpURLConnection.getContentType());

                return (httpURLConnection.getResponseCode() == HttpURLConnection.HTTP_OK && StringUtils.endsWithAny(httpURLConnection
                        .getContentType(), VALID_CONTENT_TYPES));
            } catch (Exception e) {
                System.out.println(e);
                return false;
            }
        } else {
            System.out.println("Valid extension");
            return true;
        }
    }
}
