package com.tvg.server.action.application;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import com.tvg.server.action.RegistrationAction;

public class RegistrationActionApplication extends Application{

	@Override
	public Set<Class<?>> getClasses(){
		Set<Class<?>> classes = new HashSet<Class<?>>();
		classes.add(RegistrationAction.class);
		return classes;
	}
	
}
