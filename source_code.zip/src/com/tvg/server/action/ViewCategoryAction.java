package com.tvg.server.action;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.StreamingOutput;

import net.sf.json.JSONObject;

import com.tvg.server.exception.TVGException;
import com.tvg.server.response.ViewCategoryResponse;
import com.tvg.server.service.ViewCategoryService;
import com.tvg.server.serviceImpl.ViewCategoryServiceImpl;
import com.tvg.server.util.bean.CategoryBean;


@Path(value="/category")
public class ViewCategoryAction {
	
	private ViewCategoryService categoryService;
	
	public ViewCategoryAction(){
		categoryService = new ViewCategoryServiceImpl();
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="all")
	public StreamingOutput getAllCategories(){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				JSONObject responseData = new JSONObject();
				List<CategoryBean> catList;
				try{					
					catList = categoryService.getAllCategories();
				}catch(Exception ex){
					catList = new ArrayList<CategoryBean>();
					new TVGException("Exception in View Category Action : "+ex);
				}
				responseData = ViewCategoryResponse.generateCategoryResponse(catList);
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="details/all")
	public StreamingOutput getAllCategoryDetails(){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				JSONObject responseData = new JSONObject();
				CategoryBean categoryDetails;
				try{
					categoryDetails = categoryService.getAllCategoryDetails();
					responseData = ViewCategoryResponse.generateCategoryDetailsResponse(categoryDetails);
				}catch(Exception ex){
					new TVGException("Exception in View Category Action : "+ex);
				}
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="details")
	public StreamingOutput getCategoryDetails(@FormParam("id") final int id){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				JSONObject responseData = new JSONObject();
				CategoryBean categoryDetails;
				try{
					categoryDetails = categoryService.getCategoryDetails(id);
					responseData = ViewCategoryResponse.generateCategoryDetailsResponse(categoryDetails);
				}catch(Exception ex){
					new TVGException("Exception in View Category Action : "+ex);
				}
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}
	
}
