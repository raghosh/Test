package com.tvg.server.action;

import java.io.IOException;
import java.io.OutputStream;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.StreamingOutput;

import net.sf.json.JSONObject;


import com.tvg.server.exception.TVGException;
import com.tvg.server.response.LoginResponse;
import com.tvg.server.service.LoginService;
import com.tvg.server.serviceImpl.LoginServiceImpl;
import com.tvg.server.util.bean.LoginResponseBean;

@Path(value="/login")
public class LoginAction {

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public StreamingOutput loginUser(@FormParam("userName") final String userName, @QueryParam("password") final String password){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				JSONObject responseData = new JSONObject();
				LoginResponseBean loginBean;
				try{
					LoginService loginService = new LoginServiceImpl();
					loginBean = loginService.getLoginData(userName, password);
					responseData = LoginResponse.generateLoginResponse(loginBean);
				}catch(Exception ex){
					new TVGException("Exception in login action : "+ex);
				}
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}
	
}
