package com.tvg.server.action;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;
import javax.ws.rs.core.Response.ResponseBuilder;

import net.sf.json.JSONObject;


import com.tvg.server.constant.Constants;
import com.tvg.server.exception.TVGException;
import com.tvg.server.response.UserResponse;
import com.tvg.server.service.UserInfoService;
import com.tvg.server.serviceImpl.UserInfoServiceImpl;
import com.tvg.server.util.bean.MilestoneBean;
import com.tvg.server.util.bean.ResponseStatusBean;
import com.tvg.server.util.bean.UserInfoBean;

@Path(value="/user")
public class UserProfileAction {
	
	private UserInfoService userInfoService;
	
	public UserProfileAction(){
		userInfoService = new UserInfoServiceImpl();
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="viewProfile")
	public StreamingOutput viewProfile(@FormParam("uid") final String uid){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				JSONObject responseData = new JSONObject();
				UserInfoBean userBean = new UserInfoBean();
				try{
					userBean = userInfoService.getUserInfo(uid);
					responseData = UserResponse.viewProfileResponse(userBean);
				}catch(Exception ex){
					new TVGException("Error in viewProfile : "+ex);
				}
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="changePass")
	public Response changePassword(@FormParam("userId") final String userId, @FormParam("newPass") final String newPass){
		boolean response = false;
		try{
			response = userInfoService.changePassword(userId, newPass);
		}catch(Exception ex){
			new TVGException("Error in change password : "+ex);
		}
		if(response)
			return Response.ok().build();
		else
			return Response.serverError().build();
	}
	
	@POST
	@Path(value="follow")
	public Response followUser(@FormParam("userId") final String userId, @FormParam("followed_by") final String followed_by){
		boolean response = false;
		try{
			response = userInfoService.followUser(userId, followed_by);
		}catch(Exception ex){
			new TVGException("Error in follow user : "+ex);
		}
		if(response)
			return Response.ok().build();
		else
			return Response.serverError().build();
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="milestone")
	public StreamingOutput viewUserMilestones(@FormParam("uid") final String uid){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				JSONObject responseData = new JSONObject();
				List<MilestoneBean> milestoneBean;
				try{
					milestoneBean = userInfoService.getUserMilestone(uid);
				}catch(Exception ex){
					milestoneBean = new ArrayList<MilestoneBean>();
					new TVGException("Error in view user milestone : "+ex);
				}
				responseData = UserResponse.userMilestoneResponse(milestoneBean);
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="check")
	public StreamingOutput checkEmail(@FormParam("email") final String email){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				JSONObject responseData = new JSONObject();
				ResponseStatusBean respStatus = new ResponseStatusBean();
				try{
					respStatus = userInfoService.checkEmail(email);
				}catch(Exception ex){
					new TVGException("Error in check email : "+ex);
				}
				responseData = UserResponse.generateCheckEmailResp(respStatus);
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="changeEmail")
	public Response changeEmail(@FormParam("userId") final String userId, @FormParam("email") final String email){
		boolean response = false;
		try{
			response = userInfoService.changeEmail(userId, email);
		}catch(Exception ex){
			new TVGException("Error in change email : "+ex);
		}
		if(response)
			return Response.ok().build();
		else
			return Response.serverError().build();
	}
	
	@POST
	@Path(value="profileImage")
	@Produces("image/jpg")
	public Response getPorfilePicture(@FormParam("userName") String userName){
		String fileName = userName+".jpg";
		File file;
		file = new File(Constants.BASE_IMAGE_PATH+File.separator+Constants.PROFILE_PICTURE_PATH+File.separator+fileName);
		if(!file.exists()){
			fileName = "no-image.jpg";
			file = new File(Constants.BASE_IMAGE_PATH+File.separator+Constants.COMMON_IMAGE_PATH+File.separator+fileName);
		}
		
		ResponseBuilder response = Response.ok((Object) file);
		response.header("Content-Disposition",
				"attachment; filename="+fileName);
		return response.build();
	}
	
	@POST
	@Path("profileImage/upload")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadProfilePicture(
		@FormParam("file") InputStream uploadedInputStream, @FormParam("userName") String userName) {		
		// save it
		try {
			String path = Constants.BASE_IMAGE_PATH;
			File folder = new File(path);
			if(!folder.exists())
				folder.mkdir();
			
			path = path+File.separator+Constants.PROFILE_PICTURE_PATH;
			
			folder = new File(path);
			if(!folder.exists())
				folder.mkdir();
			
			path = path+File.separator+userName+".jpg";
			
			if(uploadedInputStream != null){
				BufferedImage bImageFromConvert = ImageIO.read(uploadedInputStream);
   					 
				ImageIO.write(bImageFromConvert, "jpg", new File(path));
			}
		} catch (IOException ioe) {
			new TVGException("IOException in image Upload : "+ioe);
		}catch (Exception ioe) {
			new TVGException("Exception in image Upload : "+ioe);
		}
		return Response.status(200).build(); 
	}
	
}
