package com.tvg.server.action.validate;

import com.tvg.server.constant.Constants;
import com.tvg.server.util.bean.ResponseStatusBean;

/**
 * 
 * This class contains the validations of the request parameters
 *
 */
public class ValidateRegisterationRequestParam {

	/**
	 *  
	 * Validation method for registration parameters
	 *  
	 */
	public static ResponseStatusBean validateRegistrationParams(String userName, String password, String firstName, 
			String lastName, String sex){
		ResponseStatusBean status = new ResponseStatusBean();
		
		if(userName == null || userName.trim().equals("")){
			status.setReturnCode(1);
			status.setErrorText(Constants.MISSING_REQUIRED_PARAM+"userName");
			return status;
		}
		if(password == null || password.trim().equals("")){
			status.setReturnCode(1);
			status.setErrorText(Constants.MISSING_REQUIRED_PARAM+"password");
			return status;
		}
//		if(firstName == null || firstName.trim().equals("")){
//			status.setReturnCode(1);
//			status.setErrorText(Constants.MISSING_REQUIRED_PARAM+"firstName");
//			return status;
//		}
//		if(lastName == null || lastName.trim().equals("")){
//			status.setReturnCode(1);
//			status.setErrorText(Constants.MISSING_REQUIRED_PARAM+"lastName");
//			return status;
//		}
//		if(sex == null || sex.trim().equals("")){
//			status.setReturnCode(1);
//			status.setErrorText(Constants.MISSING_REQUIRED_PARAM+"sex");
//			return status;
//		}
		status.setReturnCode(0);
		return status;
	}
	
	/**
	 *  
	 * Validation method for check user parameters
	 *  
	 */
	public static ResponseStatusBean validateCheckUserParams(String userName){
		ResponseStatusBean status = new ResponseStatusBean();
		if(userName == null || userName.trim().equals("")){
			status.setReturnCode(1);
			status.setErrorText(Constants.MISSING_REQUIRED_PARAM+"userName");
			return status;
		}
		return status;
	}
	
}
