package com.tvg.server.action.validate;


import com.sun.jersey.core.header.FormDataContentDisposition;
import com.tvg.server.constant.Constants;
import com.tvg.server.util.bean.ResponseStatusBean;

public class ValidateMilestoneRequestParam {

	public static ResponseStatusBean validateCreateMilestoneParams(String display_name, String created_by, String url, FormDataContentDisposition is){
		ResponseStatusBean response = new ResponseStatusBean();
		if(display_name == null || display_name.trim().equals("")){
			response.setReturnCode(1);
			response.setErrorText(Constants.MISSING_REQUIRED_PARAM+"name");
			return response;
		}
		
		if(created_by == null || created_by.trim().equals("")){
			response.setReturnCode(1);
			response.setErrorText(Constants.MISSING_REQUIRED_PARAM+"userName");
			return response;
		}		
		
		if((is == null || is.getFileName() == null || is.getFileName().equals("")) && (url == null || url.trim().equals(""))){
			response.setReturnCode(1);
			response.setErrorText(Constants.MISSING_REQUIRED_PARAM+"image");
			return response;
		}
		
		response.setReturnCode(0);
		return response;
	}
	
}
