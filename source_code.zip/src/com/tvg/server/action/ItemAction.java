package com.tvg.server.action;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.tvg.server.exception.TVGException;
import com.tvg.server.service.ShareItemService;
import com.tvg.server.serviceImpl.ShareItemServiceImpl;

@Path(value="/item")
public class ItemAction {
	
	private ShareItemService itemService;
	
	public ItemAction(){
		itemService = new ShareItemServiceImpl();
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="vote")
	public Response custVote(@FormParam("itemId") final String itemId, @FormParam("mid") final String mid, @FormParam("uid") final String uid, @FormParam("vote") final int vote){
		boolean response = false;
		try{
			response = itemService.custItemVote(itemId, mid, uid, vote);					
		}catch(Exception ex){
			new TVGException("Exception in vote milestone action : "+ex);
		}
		if(response)
			return Response.ok().build();
		else
			return Response.serverError().build();
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path(value="comment")
	public Response itemComment(@FormParam("itemId") final String itemId, @FormParam("uid") final String uid, @FormParam("comment") final String comment){
		boolean response = false;
		try{
			response = itemService.postComment(itemId, uid, comment);				
		}catch(Exception ex){
			new TVGException("Exception in vote milestone action : "+ex);
		}
		if(response)
			return Response.ok().build();
		else
			return Response.serverError().build();
	}
	
}
