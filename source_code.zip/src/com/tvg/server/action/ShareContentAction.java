package com.tvg.server.action;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.StreamingOutput;

import net.sf.json.JSONObject;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.tvg.server.constant.Constants;
import com.tvg.server.exception.TVGException;
import com.tvg.server.response.MilestoneResponse;
import com.tvg.server.service.ShareItemService;
import com.tvg.server.serviceImpl.ShareItemServiceImpl;
import com.tvg.server.util.FileUtil;
import com.tvg.server.util.UniqueKey;
import com.tvg.server.util.UploadContent;
import com.tvg.server.util.bean.ContentUploadBean;
import com.tvg.server.util.bean.ResponseStatusBean;


@Path(value="/content")
public class ShareContentAction {
	
	ShareItemService shareItemService;
	
	public ShareContentAction(){
		shareItemService = new ShareItemServiceImpl();
	}
	
	@POST
	@Path(value="milestone/image")
	@Produces("image/jpeg")
	public Response getMilestoneImage(@FormParam("uid") String uid, @FormParam("mid") String mid){
		String fileName = uid+".jpg";
		File file;
		ResponseBuilder response = null;
		try{
			
			file = new File(Constants.BASE_IMAGE_PATH+File.separator+Constants.SHARED_MILESTONE_PATH+File.separator+mid+File.separator+Constants.SHARED_IMAGE_PATH+File.separator+fileName);
			
			if(!file.exists())
				file = new File(Constants.BASE_IMAGE_PATH+File.separator+Constants.COMMON_IMAGE_PATH+File.separator+Constants.NO_MILESTONE_IMAGE);
			
			response = Response.ok((Object) file);
			response.header("Content-Disposition",
					"attachment; filename="+fileName);
		}catch(Exception ex){
			new TVGException("Exception in getMilestoneImage : "+ex);
		}
		return response.build();
	}
	
	@POST
	@Path(value="milestone/video")
	public Response getMilestoneVideo(@FormParam("uid") String uid, @FormParam("mid") String mid, 
			@FormParam("ext") String ext, @FormParam("type") String type){
		String fileName = uid+"."+ext;
		File file;
		ResponseBuilder response = null;
		try{
			file = new File(Constants.BASE_IMAGE_PATH+File.separator+Constants.SHARED_IMAGE_PATH+File.separator+mid+File.separator+fileName);
			if(!file.exists()){
				return Response.ok(404).build();
			}				
			
			response = Response.ok(file, type);
			response.header("Content-Disposition",
					"attachment; filename="+fileName);
		}catch(Exception ex){
			new TVGException("Exception in getMilestoneVideo : "+ex);
		}
		return response.build();
	}
	
	@POST
	@Path("milestone/upload")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public StreamingOutput uploadFile(@FormParam("file") final InputStream uploadedInputStream, @FormParam("file") final FormDataContentDisposition fileDetail, 
			@FormParam("url") final String url, @FormParam("title") final String title, @FormParam("milestoneId") final String milestoneId, @FormParam("userName") final String userName) {		
		// save it
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				ResponseStatusBean responseStatusBan = new ResponseStatusBean();
				ContentUploadBean contentBean;
				JSONObject responseData;
				try {
					contentBean = UploadContent.upload(uploadedInputStream, fileDetail, url, milestoneId);
					
					if(contentBean.getReturnCode() == 0){
						
						boolean response = shareItemService.sharePicture(contentBean.getItem_id(), userName, title, milestoneId, contentBean.getItemType(), 
								contentBean.getContentType(), contentBean.getExtention(), contentBean.getMimeType(), url);
						responseStatusBan.setReturnCode(0);
						if(!response){
							String path = Constants.BASE_IMAGE_PATH+File.separator+Constants.SHARED_MILESTONE_PATH+File.separator+milestoneId;
							if(contentBean.getItemType().equals(Constants.IMAGE))
								path = path+File.separator+Constants.SHARED_IMAGE_PATH+contentBean.getItem_id()+".jpg";
							else
								path = path+File.separator+Constants.SHARED_VIDEO_PATH+contentBean.getItem_id()+"."+contentBean.getExtention();
							File file = new File(path);
							if(file.exists())
								file.delete();
							
							responseStatusBan.setReturnCode(1);
							responseStatusBan.setErrorText(Constants.SERVER_ERROR);
						}
					}else{
						responseStatusBan.setReturnCode(1);
						responseStatusBan.setErrorText(contentBean.getErrorText());
					}
					
				}catch (Exception ioe) {
					responseStatusBan.setReturnCode(1);
					responseStatusBan.setErrorText(Constants.SERVER_ERROR);
					new TVGException("Exception in image Upload : "+ioe);
				}
				responseData = MilestoneResponse.uploadContentResponse(responseStatusBan);
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
		
	}
	
	@POST
	@Path("milestone/link")
	@Produces(MediaType.APPLICATION_JSON)
	public StreamingOutput shareLink(@FormParam("userName") final String userName, @FormParam("title") final String title, 
			@FormParam("url") final String url, @FormParam("milestoneId") final String milestoneId){
		return new StreamingOutput() {
			
			public void write(OutputStream output) throws IOException,
					WebApplicationException {
				// TODO Auto-generated method stub
				ResponseStatusBean responseStatusBan = new ResponseStatusBean();
				JSONObject responseData;
				boolean isValid = false;
				String itemId;
				try{
					isValid = FileUtil.checkValidUrl(url);
					if(isValid){
						itemId = "I_"+UniqueKey.getKey();
						boolean response = shareItemService.shareURL(itemId, userName, title, url, milestoneId);
						if(!response){
							responseStatusBan.setReturnCode(1);
							responseStatusBan.setErrorText(Constants.SERVER_ERROR);
						}else
							responseStatusBan.setReturnCode(0);
					}else{
						responseStatusBan.setReturnCode(1);
						responseStatusBan.setErrorText("Invalid URL");
					}
				}catch(Exception ex){
					responseStatusBan.setReturnCode(1);
					responseStatusBan.setErrorText(Constants.SERVER_ERROR);
					new TVGException("Exception in link Upload : "+ex);
				}
				responseData = MilestoneResponse.uploadContentResponse(responseStatusBan);
				byte[] out = responseData.toString().getBytes();/* get some bytes to write */
		        output.write(out);
			}
		};
	}
	
}
