package com.tvg.server.serviceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tvg.server.constant.Constants;
import com.tvg.server.db.sql.MySqlQuery;
import com.tvg.server.db.util.DBConnection;
import com.tvg.server.exception.TVGException;
import com.tvg.server.service.UserInfoService;
import com.tvg.server.util.bean.CategoryBean;
import com.tvg.server.util.bean.MilestoneBean;
import com.tvg.server.util.bean.ResponseStatusBean;
import com.tvg.server.util.bean.UserInfoBean;

public class UserInfoServiceImpl implements UserInfoService {
	
	Connection connection = null;
	PreparedStatement psmt = null;
	ResultSet rsltSet = null;
	DBConnection dbConnection = new DBConnection();
	private Connection getConnection() {
		if(connection == null)
			connection = dbConnection.openConnection();
		return connection;
	}

	public UserInfoBean getUserInfo(String uid) {
		// TODO Auto-generated method stub
		UserInfoBean userBean = new UserInfoBean();
		List<Integer> followedCategoryList = new ArrayList<Integer>();
		List<UserInfoBean> followedUserList = new ArrayList<UserInfoBean>();
		UserInfoBean followedUserBean;
		List<CategoryBean> categoryList = new ArrayList<CategoryBean>();
		CategoryBean categoryBean;
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.GET_USER_INFO);
			psmt.setString(1, uid);
			rsltSet = psmt.executeQuery();
			if(rsltSet.next()){
				userBean.setUserName(rsltSet.getString("user_id"));
				userBean.setFirstName(rsltSet.getString("fname"));
				userBean.setMidName(rsltSet.getString("mname"));
				userBean.setLastName(rsltSet.getString("lname"));
				userBean.setSex(rsltSet.getString("sex"));
				
				psmt = getConnection().prepareStatement(MySqlQuery.GET_FOLLOWED_CATEGORY);
				psmt.setString(1, uid);
				rsltSet = psmt.executeQuery();
				while(rsltSet.next()){
					followedCategoryList.add(rsltSet.getInt("category"));
				}
				userBean.setFollowedCategoryList(followedCategoryList);
				
				psmt = getConnection().prepareStatement(MySqlQuery.GET_FOLLOWED_USERS);
				psmt.setString(1, uid);
				rsltSet = psmt.executeQuery();
				while(rsltSet.next()){
					followedUserBean = new UserInfoBean();
					followedUserBean.setUserName(rsltSet.getString("followed_by"));
					followedUserBean.setFirstName(rsltSet.getString("fname"));
					followedUserBean.setLastName(rsltSet.getString("lname"));
					
					followedUserList.add(followedUserBean);
				}
				userBean.setFollwedUserList(followedUserList);
				
				psmt = getConnection().prepareStatement(MySqlQuery.GEL_ALL_CATEGORIES);
				rsltSet = psmt.executeQuery();
				while(rsltSet.next()){
					categoryBean = new CategoryBean();
					categoryBean.setId(rsltSet.getInt("id"));
					categoryBean.setCategory_name(rsltSet.getString("category_name"));
					
					categoryList.add(categoryBean);
				}
				userBean.setCategoryList(categoryList);
			}
		}catch(SQLException sql){
			new TVGException("SQLException in get user info : "+sql);
		}catch(Exception ex){
			new TVGException("Exception in get user info : "+ex);
		}finally{
			closeConnection(connection);
		}
		return userBean;
	}
	
	public boolean changePassword(String userId, String newPass){
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.CHANGE_PASSWORD);
			psmt.setString(1, newPass);
			psmt.setString(2, userId);
			psmt.executeUpdate();
			return true;
		}catch(SQLException ex){
			new TVGException("SQLException in change password service : "+ex);
			return false;
		}catch(Exception ex){
			new TVGException("Exception in change password service : "+ex);
			return false;
		}finally{
			closeConnection(connection);
		}
	}
	
	public boolean followUser(String userId, String followed_by){
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.FOLLOW_USER);
			psmt.setString(1, userId);
			psmt.setString(2, followed_by);
			psmt.executeUpdate();
			return true;
		}catch(SQLException ex){
			new TVGException("SQLException in follow user service : "+ex);
			return false;
		}catch(Exception ex){
			new TVGException("Exception in follow user service : "+ex);
			return false;
		}finally{
			closeConnection(connection);
		}
	}
	
	public List<MilestoneBean> getUserMilestone(String userId){
		List<MilestoneBean> milestoneList = new ArrayList<MilestoneBean>();
		MilestoneBean milestoneBean;
		ResultSet rsltSet2 = null;
		int imageCount = 0;
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.USER_MILESTONES);
			psmt.setString(1, userId);
			psmt.setString(2, userId);
			rsltSet = psmt.executeQuery();
			while(rsltSet.next()){
				milestoneBean = new MilestoneBean();
				milestoneBean.setMilestoneId(rsltSet.getString("milestone_id"));
				milestoneBean.setMilestone_name(rsltSet.getString("display_name"));
				milestoneBean.setDescription(rsltSet.getString("description"));
				milestoneBean.setCategory(rsltSet.getString("category_name"));
				milestoneBean.setCreated_by(rsltSet.getString("created_by"));
				
				psmt = getConnection().prepareStatement(MySqlQuery.MILESTONE_IMAGE_COUNT);
				psmt.setString(1, rsltSet.getString("milestone_id"));
				rsltSet2 = psmt.executeQuery();
				if(rsltSet2.next()){
					imageCount = rsltSet2.getInt("imageCount");
				}
				
				if(imageCount == 1){
					// get the image URL
					psmt = getConnection().prepareStatement(MySqlQuery.FETCH_MILESTONE_IMAGE);
					psmt.setString(1, rsltSet.getString("milestone_id"));
					rsltSet2 = psmt.executeQuery();
					if(rsltSet2.next()){
						milestoneBean.setCover_image(rsltSet2.getString("url"));
					}
				}else if (imageCount > 1){
					// get max likes image url
					psmt = getConnection().prepareStatement(MySqlQuery.FETCH_TOP_VOTED_IMAGE);
					psmt.setString(1, rsltSet.getString("milestone_id"));
					rsltSet2 = psmt.executeQuery();
					if(rsltSet2.next()){
						milestoneBean.setCover_image(rsltSet2.getString("url"));
					}
				}
				
				milestoneList.add(milestoneBean);
			}
		}catch(Exception ex){
			new TVGException("Exception in user milestone service : "+ex);
		}finally{
			closeConnection(connection);
		}
		return milestoneList;
	}
	
	public ResponseStatusBean checkEmail(String email){
		ResponseStatusBean response = new ResponseStatusBean();
		int emailCount = -1;
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.CHECK_EMAIL);
			psmt.setString(1, email);
			rsltSet = psmt.executeQuery();
			if(rsltSet.next()){
				emailCount = rsltSet.getInt("emailCount");
			}
			if(emailCount == 0){
				response.setReturnCode(0);
			}else{
				response.setReturnCode(1);
				response.setErrorText("Email id already in use.");
			}
		}catch(SQLException sql){
			response.setReturnCode(1);
			response.setErrorText(Constants.SERVER_ERROR);
			new TVGException("SQLException in check email : "+sql);
		}catch(Exception ex){
			response.setErrorText(Constants.SERVER_ERROR);
			response.setReturnCode(1);
			new TVGException("Error in check email : "+ex);
		}finally{
			closeConnection(connection);
		}
		return response;
	}
	
	public boolean changeEmail(String userId, String email){
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.CHANGE_EMAIL);
			psmt.setString(1, email);
			psmt.setString(2, userId);
			psmt.executeUpdate();
			return true;
		}catch(SQLException ex){
			new TVGException("SQLException in change email service : "+ex);
			return false;
		}catch(Exception ex){
			new TVGException("Exception in change email service : "+ex);
			return false;
		}finally{
			closeConnection(connection);
		}
	}
	
	private void closeConnection(Connection conn){
		try{
			if(conn != null)
				dbConnection.closeConnection(conn);
		}catch(Exception ex){
			new TVGException("Error in close connection in LoginServiceImpl : "+ex);
		}
	}

}
