package com.tvg.server.serviceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tvg.server.action.validate.ValidateRegisterationRequestParam;
import com.tvg.server.constant.Constants;
import com.tvg.server.db.sql.MySqlQuery;
import com.tvg.server.db.util.DBConnection;
import com.tvg.server.exception.TVGException;
import com.tvg.server.service.RegistrationService;
import com.tvg.server.util.bean.ResponseStatusBean;

/**
 * 
 * Implementation of RegistrationService
 *
 */
public class RegistrationServiceImpl implements RegistrationService {

	Connection connection = null;
	PreparedStatement psmt = null;
	ResultSet rsltSet = null;
	DBConnection dbConnection = new DBConnection();
	private Connection getConnection() {
		connection = dbConnection.openConnection();
		return connection;
	}
	
	/**
	 * 	User registration method
	 */
	public ResponseStatusBean registerUser(String userName, String password, String firstName, String midName, 
			String lastName, String sex) {
		// TODO Auto-generated method stub
		ResponseStatusBean responseStatus = new ResponseStatusBean();
		try{
				psmt = getConnection().prepareStatement(MySqlQuery.REGISTER_USER);
				psmt.setString(1, userName);
				psmt.setString(2, password);
				psmt.setString(3, firstName);
				psmt.setString(4, midName);
				psmt.setString(5, lastName);
				psmt.setString(6, sex);
				psmt.executeUpdate();
		}catch(SQLException sql){
			responseStatus.setReturnCode(1);
			responseStatus.setErrorText(Constants.SERVER_ERROR);
			new TVGException("SQLException in registerUser : "+sql);
		}catch(Exception ex){
			responseStatus.setErrorText(Constants.SERVER_ERROR);
			responseStatus.setReturnCode(1);
			new TVGException("Error in registerUser : "+ex);
		}finally{
			closeConnection(connection);
		}
		
		return responseStatus;
	}
	
	/**
	 * 	Check user method
	 */
	public ResponseStatusBean checkUser(String userName){
		ResponseStatusBean responseStatus;
		int userCount = -1;
		try{
			responseStatus = ValidateRegisterationRequestParam.validateCheckUserParams(userName);
			if(responseStatus.getReturnCode() == 0){
				psmt = getConnection().prepareStatement(MySqlQuery.CHECK_USER);
				psmt.setString(1, userName);
				rsltSet = psmt.executeQuery();
				while(rsltSet.next()){
					userCount = rsltSet.getInt("userCount");
				}
				if(userCount != 0){
					responseStatus.setReturnCode(1);
					responseStatus.setErrorText("Username already in use.");
				}
			}
		}catch(SQLException sql){
			responseStatus = new ResponseStatusBean();
			responseStatus.setReturnCode(1);
			responseStatus.setErrorText(Constants.SERVER_ERROR);
			new TVGException("SQLException in checkUser : "+sql);
		}catch(Exception ex){
			responseStatus = new ResponseStatusBean();
			responseStatus.setErrorText(Constants.SERVER_ERROR);
			responseStatus.setReturnCode(1);
			new TVGException("Error in checkUser : "+ex);
		}finally{
			closeConnection(connection);
		}
		
		return responseStatus;
	}
	
	/**
	 * 
	 * @param conn
	 */
	private void closeConnection(Connection conn){
		try{
			if(conn != null)
				dbConnection.closeConnection(conn);
		}catch(Exception ex){
			new TVGException("Error in close connection in RegistrationServiceImpl : "+ex);
		}
	}

}
