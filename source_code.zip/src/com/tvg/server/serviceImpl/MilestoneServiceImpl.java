package com.tvg.server.serviceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tvg.server.constant.Constants;
import com.tvg.server.db.sql.MySqlQuery;
import com.tvg.server.db.util.DBConnection;
import com.tvg.server.exception.TVGException;
import com.tvg.server.service.MilestoneService;
import com.tvg.server.util.bean.CommentBean;
import com.tvg.server.util.bean.ItemDetailsBean;
import com.tvg.server.util.bean.MilestoneDetailsBean;
import com.tvg.server.util.bean.ResponseStatusBean;
import com.tvg.server.util.bean.UserInfoBean;

public class MilestoneServiceImpl implements MilestoneService {

	Connection connection = null;
	PreparedStatement psmt = null;
	ResultSet rsltSet = null;
	DBConnection dbConnection = new DBConnection();
	private Connection getConnection() {
		if(connection == null)
			connection = dbConnection.openConnection();
		return connection;
	}
	
	public ResponseStatusBean createMilestone(String milestone_id, String display_name,
			String description, int category, String tags, String itemId, String url, String title, String contentType, 
			String itemType, String created_by, String mimeType, String extention) {
		// TODO Auto-generated method stub
		ResponseStatusBean response = new ResponseStatusBean();
		String content_uri;
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.CREATE_MILESTONE);
			psmt.setString(1, milestone_id);
			psmt.setString(2, display_name);
			psmt.setString(3, description);
			psmt.setInt(4, category);
			psmt.setString(5, tags);
			psmt.setString(6, itemId);
			psmt.setString(7, created_by);
			psmt.executeUpdate();
			
			if(itemType.equals(Constants.IMAGE))
				content_uri = Constants.SHARE_IMAGE_URI + Constants.UID + itemId + Constants.MID + milestone_id;
			else
				content_uri = Constants.SHARE_VIDEO_URI + Constants.UID + itemId + Constants.MID + milestone_id+"&ext="+extention+"&type="+mimeType;
			
			
			psmt = getConnection().prepareStatement(MySqlQuery.SHARE_ITEMS);
			psmt.setString(1, itemId);
			
			if(contentType.equals("url"))
				psmt.setString(2, url);
			else
				psmt.setString(2, content_uri);
			
			psmt.setString(3, title);
			
			if(itemType.equals(Constants.IMAGE))
				psmt.setInt(4, 2);	// item type : image
			else
				psmt.setInt(4, 3);	// item type : video
			
			psmt.setString(5, created_by);
			psmt.setString(6, milestone_id);
			psmt.executeUpdate();
			
			psmt = getConnection().prepareStatement(MySqlQuery.INSERT_MILESTONE_MEMBER);
			psmt.setString(1, milestone_id);
			psmt.setString(2, created_by);
			psmt.executeUpdate();
			
			response.setReturnCode(0);
		}catch(SQLException sql){
			response.setReturnCode(1);
			response.setErrorText(Constants.SERVER_ERROR);
			new TVGException("SQL Exception in create milestone service : "+sql);
		}catch(Exception ex){
			response.setReturnCode(1);
			response.setErrorText(Constants.SERVER_ERROR);
			new TVGException("Exception in create milestone service : "+ex);
		}finally{
			closeConnection(connection);
		}
		return response;
	}
	
	public MilestoneDetailsBean viewMilestone(String mid, String uid){
		MilestoneDetailsBean milestoneBean = new MilestoneDetailsBean();
		List<UserInfoBean> memberList;
		UserInfoBean userInfoBean;
		
		List<CommentBean> commentList = new ArrayList<CommentBean>();
		CommentBean commentBean;
		int cnt = -1;
		try{
			// Basic info about a milestone
			psmt = getConnection().prepareStatement(MySqlQuery.VIEW_MILESTONE_DETAILS);
			psmt.setString(1, mid);
			rsltSet = psmt.executeQuery();
			if(rsltSet.next()){
				milestoneBean.setReturn_code(0);
				milestoneBean.setMilestone_id(rsltSet.getString("milestone_id"));
				milestoneBean.setDisplay_name(rsltSet.getString("display_name"));
				milestoneBean.setDescription(rsltSet.getString("description"));
				milestoneBean.setCategory_name(rsltSet.getString("category_name"));
				milestoneBean.setCreated_by(rsltSet.getString("created_by"));
			}else{
				milestoneBean.setReturn_code(1);
				milestoneBean.setError_text("No Data Found.");
			}
			psmt.close();
			rsltSet.close();
			
			if(milestoneBean.getReturn_code() == 0){
				// Fetch the milestone vote
				psmt = getConnection().prepareStatement(MySqlQuery.CHECK_MILESTONE_VOTE);
				psmt.setString(1, mid);
				psmt.setString(2, uid);
				rsltSet = psmt.executeQuery();
				if(rsltSet.next()){
					milestoneBean.setVote(rsltSet.getInt("vote"));
				}else{
					milestoneBean.setVote(-1);
				}
				psmt.close();
				rsltSet.close();
				
				// Membership details
				psmt = getConnection().prepareStatement(MySqlQuery.CHECK__MILESTONE_MEMBER);
				psmt.setString(1, mid);
				psmt.setString(2, uid);
				rsltSet = psmt.executeQuery();
				while(rsltSet.next()){
					cnt = rsltSet.getInt("cnt");
				}
				if(cnt == 1){
					milestoneBean.setMember(true);
				}else{
					milestoneBean.setMember(false);
				}
				cnt = -1;
				// Follower details
				psmt = getConnection().prepareStatement(MySqlQuery.CHECK_FOLLOW_MILESTONE);
				psmt.setString(1, mid);
				psmt.setString(2, uid);
				rsltSet = psmt.executeQuery();
				while(rsltSet.next()){
					cnt = rsltSet.getInt("cnt");
				}
				if(cnt == 1){
					milestoneBean.setFollowing(true);
				}else{
					milestoneBean.setFollowing(false);
				}
				
				// List of the members of milestone
				psmt = getConnection().prepareStatement(MySqlQuery.VIEW_MILESTONE_MEMBERS);
				psmt.setString(1, mid);
				rsltSet = psmt.executeQuery();
				if(rsltSet.next()){
					rsltSet.beforeFirst();
					memberList = new ArrayList<UserInfoBean>();
					while(rsltSet.next()){
						userInfoBean = new UserInfoBean();
						userInfoBean.setFirstName(rsltSet.getString("fname"));
						userInfoBean.setLastName(rsltSet.getString("lname"));
						userInfoBean.setUserName(rsltSet.getString("member"));
						
						memberList.add(userInfoBean);
					}
					milestoneBean.setMilestoneMembers(memberList);
				}
				
				psmt.close();
				rsltSet.close();
				// List of the followers of milestone
				psmt = getConnection().prepareStatement(MySqlQuery.VIEW_MILESTONE_FOLLOWERS);
				psmt.setString(1, mid);
				rsltSet = psmt.executeQuery();
				if(rsltSet.next()){
					rsltSet.beforeFirst();
					memberList = new ArrayList<UserInfoBean>();
					while(rsltSet.next()){
						userInfoBean = new UserInfoBean();
						userInfoBean.setFirstName(rsltSet.getString("fname"));
						userInfoBean.setLastName(rsltSet.getString("lname"));
						userInfoBean.setUserName(rsltSet.getString("followed_by"));
						
						memberList.add(userInfoBean);
					}
					milestoneBean.setMilestoneFollowers(memberList);
				}
				
				psmt.close();
				rsltSet.close();
				
				// List of the shared items
//				psmt = getConnection().prepareStatement(MySqlQuery.VIEW_MILESTONE_ITEMS);
//				psmt.setString(1, mid);
//				rsltSet = psmt.executeQuery();
//				while(rsltSet.next()){
//					sharedItem = new ItemDetailsBean();
//					sharedItem.setItem_id(rsltSet.getString("item_id"));
//					sharedItem.setUrl(rsltSet.getString("url"));
//					sharedItem.setItem_type(rsltSet.getString("type"));
//					sharedItem.setShared_by(rsltSet.getString("shared_by"));
//					sharedItem.setShare_time(rsltSet.getString("share_time"));
//					
//					sharedItemList.add(sharedItem);
//				}
//				milestoneBean.setSharedItems(sharedItemList);
				
				// List of milestone comments
				psmt = getConnection().prepareStatement(MySqlQuery.VIEW_MILESTONE_COMMENT);
				psmt.setString(1, mid);
				rsltSet = psmt.executeQuery();
				while(rsltSet.next()){
					commentBean = new CommentBean();
					commentBean.setComment(rsltSet.getString("comment"));
					commentBean.setCommented_by(rsltSet.getString("commented_by"));
					commentBean.setFname(rsltSet.getString("fname"));
					commentBean.setLname(rsltSet.getString("lname"));
					commentBean.setComment_time(rsltSet.getString("comment_time"));
					
					commentList.add(commentBean);
				}
				milestoneBean.setComments(commentList);
				
			}
		}catch(SQLException ex){
			milestoneBean.setReturn_code(1);
			milestoneBean.setError_text(Constants.SERVER_ERROR);
			new TVGException("SQLException in view milestone service : "+ex);
		}catch(Exception ex){
			milestoneBean.setReturn_code(1);
			milestoneBean.setError_text(Constants.SERVER_ERROR);
			new TVGException("Exception in view milestone service : "+ex);
		}finally{
			closeConnection(connection);
		}
		return milestoneBean;
	}
	
	public ResponseStatusBean custVote(String milestoneId, String userName, int vote){
		ResponseStatusBean response = new ResponseStatusBean();
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.CHECK_MILESTONE_VOTE);
			psmt.setString(1, milestoneId);
			psmt.setString(2, userName);
			rsltSet = psmt.executeQuery();
			if(rsltSet.next()){
				psmt = getConnection().prepareStatement(MySqlQuery.UPDATE_MILESTONE_VOTE);
				psmt.setInt(1, vote);
				psmt.setString(2, milestoneId);
				psmt.setString(3, userName);
				psmt.executeUpdate();
			}else{
				psmt = getConnection().prepareStatement(MySqlQuery.CUST_MILESTONE_VOTE);
				psmt.setString(1, milestoneId);
				psmt.setString(2, userName);
				psmt.setInt(3, vote);
				psmt.executeUpdate();
			}
			
			response.setReturnCode(0);
		}catch(SQLException sql){
			response.setReturnCode(1);
			response.setErrorText(Constants.SERVER_ERROR);
			new TVGException("SQL Exception in vote milestone service : "+sql);
		}catch(Exception ex){
			response.setReturnCode(1);
			response.setErrorText(Constants.SERVER_ERROR);
			new TVGException("Exception in vote milestone service : "+ex);
		}finally{
			closeConnection(connection);
		}
		return response;
	}
	
	public ResponseStatusBean followMilestone(String milestoneId, String userName){
		ResponseStatusBean response = new ResponseStatusBean();
		int cnt = -1;
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.CHECK_FOLLOW_MILESTONE);
			psmt.setString(1, milestoneId);
			psmt.setString(2, userName);
			rsltSet = psmt.executeQuery();
			while(rsltSet.next()){
				cnt = rsltSet.getInt("cnt");
			}
			if(cnt == 0){
				psmt = getConnection().prepareStatement(MySqlQuery.FOLLOW_MILESTONE);
				psmt.setString(1, milestoneId);
				psmt.setString(2, userName);
				psmt.executeUpdate();
			}else{
				psmt = getConnection().prepareStatement(MySqlQuery.UNFOLLOW_MILESTONE);
				psmt.setString(1, milestoneId);
				psmt.setString(2, userName);
				psmt.executeUpdate();
			}
			
			response.setReturnCode(0);
		}catch(SQLException sql){
			response.setReturnCode(1);
			response.setErrorText(Constants.SERVER_ERROR);
			new TVGException("SQL Exception in follow milestone service : "+sql);
		}catch(Exception ex){
			response.setReturnCode(1);
			response.setErrorText(Constants.SERVER_ERROR);
			new TVGException("Exception in follow milestone service : "+ex);
		}finally{
			closeConnection(connection);
		}
		return response;
	}
	
	public ResponseStatusBean joinMilestone(String milestoneId, String userName){
		ResponseStatusBean response = new ResponseStatusBean();
		int cnt = -1;
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.CHECK__MILESTONE_MEMBER);
			psmt.setString(1, milestoneId);
			psmt.setString(2, userName);
			rsltSet = psmt.executeQuery();
			while(rsltSet.next()){
				cnt = rsltSet.getInt("cnt");
			}
			if(cnt == 0){
				psmt = getConnection().prepareStatement(MySqlQuery.JOIN_MILESTONE);
				psmt.setString(1, milestoneId);
				psmt.setString(2, userName);
				psmt.executeUpdate();
			}else{
				psmt = getConnection().prepareStatement(MySqlQuery.LEAVE_MILESTONE);
				psmt.setString(1, milestoneId);
				psmt.setString(2, userName);
				psmt.executeUpdate();
			}
			
			response.setReturnCode(0);
		}catch(SQLException sql){
			response.setReturnCode(1);
			response.setErrorText(Constants.SERVER_ERROR);
			new TVGException("SQL Exception in follow milestone service : "+sql);
		}catch(Exception ex){
			response.setReturnCode(1);
			response.setErrorText(Constants.SERVER_ERROR);
			new TVGException("Exception in follow milestone service : "+ex);
		}finally{
			closeConnection(connection);
		}
		return response;
	}
	
	public boolean postComment(String mid, String uid, String comment){
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.POST_MILESTONE_COMMENT);
			psmt.setString(1, mid);
			psmt.setString(2, comment);
			psmt.setString(3, uid);
			psmt.executeUpdate();
			return true;
		}catch(SQLException sql){
			new TVGException("SQL Exception in comment milestone service : "+sql);
			return false;
		}catch(Exception ex){
			new TVGException("Exception in comment milestone service : "+ex);
			return false;
		}finally{
			closeConnection(connection);
		}
	}
	
	public List<ItemDetailsBean> viewContents(String mid){
		List<ItemDetailsBean> sharedItemList = new ArrayList<ItemDetailsBean>();
		ItemDetailsBean sharedItem;
		ResultSet rsltSet2 = null;
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.VIEW_MILESTONE_ITEMS);
			psmt.setString(1, mid);
			rsltSet = psmt.executeQuery();
			while(rsltSet.next()){
				sharedItem = new ItemDetailsBean();
				sharedItem.setItem_id(rsltSet.getString("item_id"));
				sharedItem.setUrl(rsltSet.getString("url"));
				sharedItem.setItem_type(rsltSet.getString("type"));
				sharedItem.setShared_by(rsltSet.getString("shared_by"));
				sharedItem.setShare_time(rsltSet.getString("share_time"));
				
				psmt = getConnection().prepareStatement(MySqlQuery.ITEM_VOTE_COUNT);
				psmt.setString(1, rsltSet.getString("item_id"));
				rsltSet2 = psmt.executeQuery();
				if(rsltSet2.next()){
					sharedItem.setVoteCount(rsltSet2.getInt("voteCount"));
				}else{
					sharedItem.setVoteCount(0);
				}
				
				psmt = getConnection().prepareStatement(MySqlQuery.ITEM_COMMENT_COUNT);
				psmt.setString(1, rsltSet.getString("item_id"));
				rsltSet2 = psmt.executeQuery();
				if(rsltSet2.next()){
					sharedItem.setCommentCount(rsltSet2.getInt("commentCount"));
				}else{
					sharedItem.setCommentCount(0);
				}
				
				sharedItemList.add(sharedItem);
			}			
			
		}catch(SQLException sql){
			new TVGException("SQL Exception in comment milestone service : "+sql);
			return sharedItemList;
		}catch(Exception ex){
			new TVGException("Exception in comment milestone service : "+ex);
			return sharedItemList;
		}finally{
			closeConnection(connection);
		}
		return sharedItemList;
	}
	
	public List<ItemDetailsBean> viewLinks(String mid){
		List<ItemDetailsBean> sharedItemList = new ArrayList<ItemDetailsBean>();
		ItemDetailsBean sharedItem;
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.VIEW_MILESTONE_LINKS);
			psmt.setString(1, mid);
			rsltSet = psmt.executeQuery();
			while(rsltSet.next()){
				sharedItem = new ItemDetailsBean();
				sharedItem.setItem_id(rsltSet.getString("item_id"));
				sharedItem.setUrl(rsltSet.getString("url"));
				sharedItem.setItem_type(rsltSet.getString("type"));
				sharedItem.setShared_by(rsltSet.getString("shared_by"));
				sharedItem.setShare_time(rsltSet.getString("share_time"));
				
				sharedItemList.add(sharedItem);
			}
		}catch(SQLException sql){
			new TVGException("SQL Exception in comment milestone service : "+sql);
			return sharedItemList;
		}catch(Exception ex){
			new TVGException("Exception in comment milestone service : "+ex);
			return sharedItemList;
		}finally{
			closeConnection(connection);
		}
		return sharedItemList;
	}
	
	private void closeConnection(Connection conn){
		try{
			if(conn != null)
				dbConnection.closeConnection(conn);
		}catch(Exception ex){
			new TVGException("Error in close connection in LoginServiceImpl : "+ex);
		}
	}

}
