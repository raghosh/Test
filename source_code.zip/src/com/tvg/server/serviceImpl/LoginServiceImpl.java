package com.tvg.server.serviceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.tvg.server.constant.Constants;
import com.tvg.server.db.sql.MySqlQuery;
import com.tvg.server.db.util.DBConnection;
import com.tvg.server.exception.TVGException;
import com.tvg.server.service.LoginService;
import com.tvg.server.util.bean.CategoryBean;
import com.tvg.server.util.bean.LoginResponseBean;
import com.tvg.server.util.bean.MilestoneBean;

public class LoginServiceImpl implements LoginService {

	Connection connection = null;
	PreparedStatement psmt = null;
	ResultSet rsltSet = null;
	DBConnection dbConnection = new DBConnection();
	private Connection getConnection() {
		if(connection == null)
			connection = dbConnection.openConnection();
		return connection;
	}
	
	public LoginResponseBean getLoginData(String userName, String password) {
		// TODO Auto-generated method stub
		LoginResponseBean loginBean = new LoginResponseBean();
		List<CategoryBean> categoryList = new ArrayList<CategoryBean>();
		List<MilestoneBean> milestoneList;
		ResultSet rsltSet2 = null;
		int imageCount = 0;
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.USER_LOGIN);
			psmt.setString(1, userName);
			psmt.setString(2, password);
			rsltSet = psmt.executeQuery();
			if(rsltSet.next()){
				loginBean.setReturn_code(0);
				loginBean.setUserName(userName);
				loginBean.setFirstName(rsltSet.getString("fname"));
				loginBean.setMidName(rsltSet.getString("mname"));
				loginBean.setLastName(rsltSet.getString("lname"));
				loginBean.setSex(rsltSet.getString("sex"));
			}else{
				loginBean.setReturn_code(1);
				loginBean.setError_text("Invalid user credential.");
			}
			psmt.close();
			rsltSet.close();
			if(loginBean.getReturn_code() == 0){
				CategoryBean categoryBean;
				MilestoneBean milestoneBean;
				// Setting all category
				categoryBean = new CategoryBean();
				categoryBean.setId(0);
				categoryBean.setCategory_name("All");
				categoryList.add(categoryBean);
				
				// fetching category details				
				psmt = getConnection().prepareStatement(MySqlQuery.GEL_ALL_CATEGORIES);
				rsltSet = psmt.executeQuery();
				while(rsltSet.next()){
					categoryBean = new CategoryBean();
					categoryBean.setId(rsltSet.getInt("id"));
					categoryBean.setCategory_name(rsltSet.getString("category_name"));
					categoryList.add(categoryBean);
				}
				psmt.close();
				rsltSet.close();
				
				// Fetching Milestones for each category
				Iterator<CategoryBean>  categoryIt = categoryList.iterator();
				while(categoryIt.hasNext()){
					milestoneList = new ArrayList<MilestoneBean>();
					CategoryBean bean = categoryIt.next();
					if(bean.getId() == 0){
						psmt = getConnection().prepareStatement(MySqlQuery.ALL_MILESTONES_SUBSET);
					}else{
						psmt = getConnection().prepareStatement(MySqlQuery.MILESTONES_SUBSET);
						psmt.setInt(1, bean.getId());
					}					
					rsltSet = psmt.executeQuery();
					while(rsltSet.next()){
						milestoneBean = new MilestoneBean();
						milestoneBean.setMilestoneId(rsltSet.getString("milestone_id"));
						milestoneBean.setMilestone_name(rsltSet.getString("display_name"));
						milestoneBean.setDescription(rsltSet.getString("description"));
						
						psmt = getConnection().prepareStatement(MySqlQuery.MILESTONE_IMAGE_COUNT);
						psmt.setString(1, rsltSet.getString("milestone_id"));
						rsltSet2 = psmt.executeQuery();
						if(rsltSet2.next()){
							imageCount = rsltSet2.getInt("imageCount");
						}
						
						if(imageCount == 1){
							// get the image URL
							psmt = getConnection().prepareStatement(MySqlQuery.FETCH_MILESTONE_IMAGE);
							psmt.setString(1, rsltSet.getString("milestone_id"));
							rsltSet2 = psmt.executeQuery();
							if(rsltSet2.next()){
								milestoneBean.setCover_image(rsltSet2.getString("url"));
							}
						}else if (imageCount > 1){
							// get max likes image url
							psmt = getConnection().prepareStatement(MySqlQuery.FETCH_TOP_VOTED_IMAGE);
							psmt.setString(1, rsltSet.getString("milestone_id"));
							rsltSet2 = psmt.executeQuery();
							if(rsltSet2.next()){
								milestoneBean.setCover_image(rsltSet2.getString("url"));
							}
						}
						
						milestoneList.add(milestoneBean);						
					}
					bean.setMilestones(milestoneList);
				}
				
			}
			
			loginBean.setCategories(categoryList);
			
		}catch(SQLException sql){
			loginBean.setReturn_code(1);
			loginBean.setError_text(Constants.SERVER_ERROR);
			new TVGException("SQL Exception in login service : "+sql);
		}catch(Exception ex){
			loginBean.setReturn_code(1);
			loginBean.setError_text(Constants.SERVER_ERROR);
			new TVGException("Exception in login service : "+ex);
		}finally{
			closeConnection(connection);
		}
		return loginBean;
	}
	
	private void closeConnection(Connection conn){
		try{
			if(conn != null)
				dbConnection.closeConnection(conn);
		}catch(Exception ex){
			new TVGException("Error in close connection in LoginServiceImpl : "+ex);
		}
	}

}
