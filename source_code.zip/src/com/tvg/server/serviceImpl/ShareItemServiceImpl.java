package com.tvg.server.serviceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tvg.server.constant.Constants;
import com.tvg.server.db.sql.MySqlQuery;
import com.tvg.server.db.util.DBConnection;
import com.tvg.server.exception.TVGException;
import com.tvg.server.service.ShareItemService;

public class ShareItemServiceImpl implements ShareItemService {

	Connection connection = null;
	PreparedStatement psmt = null;
	ResultSet rsltSet = null;
	DBConnection dbConnection = new DBConnection();

	private Connection getConnection() {
		connection = dbConnection.openConnection();
		return connection;
	}

	public boolean sharePicture(String itemId, String shared_by, String title,
			String milestone_id, String itemType, String contentType, String extention, String mimeType, String url) {
		// TODO Auto-generated method stub
		String content_uri;
		try {
			if(itemType.equals(Constants.IMAGE))
				content_uri = Constants.SHARE_IMAGE_URI + Constants.UID + itemId + Constants.MID + milestone_id;
			else
				content_uri = Constants.SHARE_VIDEO_URI + Constants.UID + itemId + Constants.MID + milestone_id+"&ext="+extention+"&type="+mimeType;
			
			psmt = getConnection().prepareStatement(MySqlQuery.SHARE_ITEMS);
			psmt.setString(1, itemId);
			
			if(contentType.equals("url"))
				psmt.setString(2, url);
			else
				psmt.setString(2, content_uri);
			
			psmt.setString(3, title);
			
			if(itemType.equals(Constants.IMAGE))
				psmt.setInt(4, 2);	// item type : image
			else
				psmt.setInt(4, 3);	// item type : video
			
			psmt.setString(5, shared_by);
			psmt.setString(6, milestone_id);
			psmt.executeUpdate();
			
			return true;
		} catch (SQLException sql) {
			new TVGException("SQLException in share picture : " + sql);
			return false;
		} catch (Exception ex) {
			new TVGException("Exception in share picture : " + ex);
			return false;
		} finally {
			closeConnection(connection);
		}
	}
	
	public boolean shareURL(String itemId, String shared_by, String title, String url, String milestone_id){
		try {
			psmt = getConnection().prepareStatement(MySqlQuery.SHARE_ITEMS);
			psmt.setString(1, itemId);			
			psmt.setString(2, url);			
			psmt.setString(3, title);
			psmt.setInt(4, 1);			
			psmt.setString(5, shared_by);
			psmt.setString(6, milestone_id);
			psmt.executeUpdate();
			return true;
		}catch (SQLException sql) {
			new TVGException("SQLException in share picture : " + sql);
			return false;
		} catch (Exception ex) {
			new TVGException("Exception in share picture : " + ex);
			return false;
		} finally {
			closeConnection(connection);
		}		
	}
	
	public boolean custItemVote(String itemId, String milestoneId, String userName, int vote){
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.CHECK_ITEM_VOTE);
			psmt.setString(1, itemId);
			psmt.setString(2, userName);
			rsltSet = psmt.executeQuery();
			if(rsltSet.next()){
				psmt = getConnection().prepareStatement(MySqlQuery.UPDATE_ITEM_VOTE);
				psmt.setInt(1, vote);
				psmt.setString(2, itemId);
				psmt.setString(3, userName);
				psmt.executeUpdate();
			}else{
				psmt = getConnection().prepareStatement(MySqlQuery.CUST_ITEM_VOTE);
				psmt.setString(1, itemId);
				psmt.setInt(2, vote);
				psmt.setString(3, milestoneId);
				psmt.setString(4, userName);
				psmt.executeUpdate();
			}
			
			psmt = getConnection().prepareStatement(MySqlQuery.INCREASE_VOTE_COUNT);
			psmt.setString(1, itemId);
			psmt.executeUpdate();
			return true;
		}catch(SQLException sql){
			new TVGException("SQL Exception in custItemVote service : "+sql);
			return false;
		}catch(Exception ex){
			new TVGException("Exception in custItemVote service : "+ex);
			return false;
		}finally{
			closeConnection(connection);
		}
	}
	
	public boolean postComment(String itemId, String uid, String comment){
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.POST_ITEM_COMMENT);
			psmt.setString(1, itemId);
			psmt.setString(2, comment);
			psmt.setString(3, uid);
			psmt.executeUpdate();
			return true;
		}catch(SQLException sql){
			new TVGException("SQL Exception in comment item service : "+sql);
			return false;
		}catch(Exception ex){
			new TVGException("Exception in comment item service : "+ex);
			return false;
		}finally{
			closeConnection(connection);
		}
	}

	private void closeConnection(Connection conn) {
		try {
			if (conn != null)
				dbConnection.closeConnection(conn);
		} catch (Exception ex) {
			new TVGException(
					"Error in close connection in RegistrationServiceImpl : "
							+ ex);
		}
	}

}
