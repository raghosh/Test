package com.tvg.server.serviceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tvg.server.db.sql.MySqlQuery;
import com.tvg.server.db.util.DBConnection;
import com.tvg.server.exception.TVGException;
import com.tvg.server.service.ViewCategoryService;
import com.tvg.server.util.bean.CategoryBean;
import com.tvg.server.util.bean.MilestoneBean;

public class ViewCategoryServiceImpl implements ViewCategoryService {
	
	Connection connection = null;
	PreparedStatement psmt = null;
	ResultSet rsltSet = null;
	DBConnection dbConnection = new DBConnection();
	private Connection getConnection() {
		if(connection == null)
			connection = dbConnection.openConnection();
		return connection;
	}
	
	public List<CategoryBean> getAllCategories(){
		List<CategoryBean> catList = new ArrayList<CategoryBean>();
		CategoryBean catBean;
		try{
			psmt = getConnection().prepareStatement(MySqlQuery.ALL_CATEGORIES);
			rsltSet = psmt.executeQuery();
			while(rsltSet.next()){
				catBean = new CategoryBean();
				catBean.setId(rsltSet.getInt("id"));
				catBean.setCategory_name(rsltSet.getString("category_name"));
				
				catList.add(catBean);
			}
		}catch(SQLException ex){
			new TVGException("SQLException in ViewCategoryServiceImpl getAllCategories : "+ex);
		}catch(Exception ex){
			new TVGException("Exception in ViewCategoryServiceImpl getAllCategories : "+ex);
		}finally{
			closeConnection(connection);
		}
		return catList;
	}

	public CategoryBean getAllCategoryDetails() {
		// TODO Auto-generated method stub
		CategoryBean categoryBean = new CategoryBean();
		List<MilestoneBean> milestoneList;
		MilestoneBean milestoneBean;
		try{
			milestoneList = new ArrayList<MilestoneBean>();
			categoryBean.setId(0);
			categoryBean.setCategory_name("ALL");
			psmt = getConnection().prepareStatement(MySqlQuery.ALL_CATEGORY_DETAILS);
			rsltSet = psmt.executeQuery();
			while(rsltSet.next()){
				milestoneBean = new MilestoneBean();
				milestoneBean.setMilestoneId(rsltSet.getString("milestone_id"));
				milestoneBean.setMilestone_name(rsltSet.getString("display_name"));
				milestoneBean.setDescription(rsltSet.getString("description"));
				milestoneList.add(milestoneBean);
			}
			categoryBean.setMilestones(milestoneList);
		}catch(SQLException ex){
			new TVGException("SQLException in ViewCategoryServiceImpl getAllCategoryDetails : "+ex);
		}catch(Exception ex){
			new TVGException("Exception in ViewCategoryServiceImpl getAllCategoryDetails : "+ex);
		}finally{
			closeConnection(connection);
		}
		return categoryBean;
	}

	public CategoryBean getCategoryDetails(int categoryId) {
		// TODO Auto-generated method stub
		CategoryBean categoryBean = new CategoryBean();
		List<MilestoneBean> milestoneList;
		MilestoneBean milestoneBean;
		ResultSet rsltSet2 = null;
		int imageCount = 0;
		try{
			milestoneList = new ArrayList<MilestoneBean>();
			categoryBean.setId(categoryId);
			categoryBean.setCategory_name("ALL");
			psmt = getConnection().prepareStatement(MySqlQuery.CATEGORY_DETAILS);
			psmt.setInt(1, categoryId);
			rsltSet = psmt.executeQuery();
			while(rsltSet.next()){
				milestoneBean = new MilestoneBean();
				milestoneBean.setMilestoneId(rsltSet.getString("milestone_id"));
				milestoneBean.setMilestone_name(rsltSet.getString("display_name"));
				milestoneBean.setDescription(rsltSet.getString("description"));
				
				psmt = getConnection().prepareStatement(MySqlQuery.MILESTONE_IMAGE_COUNT);
				psmt.setString(1, rsltSet.getString("milestone_id"));
				rsltSet2 = psmt.executeQuery();
				if(rsltSet2.next()){
					imageCount = rsltSet2.getInt("imageCount");
				}
				
				if(imageCount == 1){
					// get the image URL
					psmt = getConnection().prepareStatement(MySqlQuery.FETCH_MILESTONE_IMAGE);
					psmt.setString(1, rsltSet.getString("milestone_id"));
					rsltSet2 = psmt.executeQuery();
					if(rsltSet2.next()){
						milestoneBean.setCover_image(rsltSet2.getString("url"));
					}
				}else if (imageCount > 1){
					// get max likes image url
					psmt = getConnection().prepareStatement(MySqlQuery.FETCH_TOP_VOTED_IMAGE);
					psmt.setString(1, rsltSet.getString("milestone_id"));
					rsltSet2 = psmt.executeQuery();
					if(rsltSet2.next()){
						milestoneBean.setCover_image(rsltSet2.getString("url"));
					}
				}
				
				milestoneList.add(milestoneBean);
			}
			categoryBean.setMilestones(milestoneList);
		}catch(SQLException ex){
			new TVGException("SQLException in ViewCategoryServiceImpl getCategoryDetails : "+ex);
		}catch(Exception ex){
			new TVGException("Exception in ViewCategoryServiceImpl getCategoryDetails : "+ex);
		}finally{
			closeConnection(connection);
		}
		return categoryBean;
	}
	
	private void closeConnection(Connection conn){
		try{
			if(conn != null)
				dbConnection.closeConnection(conn);
		}catch(Exception ex){
			new TVGException("Error in close connection in LoginServiceImpl : "+ex);
		}
	}

}
